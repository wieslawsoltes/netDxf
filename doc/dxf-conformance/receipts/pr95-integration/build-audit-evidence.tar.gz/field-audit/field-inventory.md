# DXF group-code and model inventory

Source revision: `71b082eaa218f3db0742176d1fa97b0a14339900`. See JSON for SHA-256 hashes, exact case bodies, write expressions, dispatch and version conditions.

**This is syntax evidence, not a coverage percentage or a conformance certificate.** A code can be consumed but ignored, emitted as a constant, conditionally omitted, handled in a helper, or valid only in a particular DXF version. A numeric case in an unrelated switch is deliberately not counted. Dynamic write-code expressions remain explicit in JSON. Unknown fields and ordering must be tested independently.

## netDxf/IO/BinaryCodeValueReader.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/BinaryCodeValueWriter.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfAcisSat.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadAcisEntity](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfAcisSat.cs#L13-L82) |  |  | version >= DxfVersion.AutoCad2013; !(entity is Solid3D) \|\| historySubclass \|\| !hasVersion \|\| parts.Count == 0 \|\|                             version < DxfVersion.AutoCad2007 \|\| this.chunk.ReadString() != SubclassMarker.Solid3D |
| [ValidateAcisEntities](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfAcisSat.cs#L87-L102) |  |  | version >= DxfVersion.AutoCad2013; entity is Solid3D solid && solid.HistoryHandle != null && version < DxfVersion.AutoCad2007 |
| [WriteAcisEntity](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfAcisSat.cs#L104-L116) |  | 70, 100, 350 (+ dynamic codes; see JSON) | entity is Solid3D solid && this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 |

## netDxf/IO/DxfAtomicFile.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfClasses.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadClassDefinitions](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfClasses.cs#L37-L82) | 1, 2, 3, 90, 91, 280, 281 |  |  |
| [WriteClassDefinition](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfClasses.cs#L146-L159) |  | 0, 1, 2, 3, 90, 91, 280, 281 | this.doc.DrawingVariables.AcadVer > DxfVersion.AutoCad2000 && definition.InstanceCount.HasValue |

## netDxf/IO/DxfEntityCommonData.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadEntityCommonData](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfEntityCommonData.cs#L39-L77) | 92, 160, 284, 310, 430 |  | version < DxfVersion.AutoCad2004 \|\| data.ColorNameSeen; version < DxfVersion.AutoCad2007 \|\| data.ShadowMode.HasValue \|\| mode < 0 \|\| mode > 3; data.DeclaredLength.HasValue \|\| (this.chunk.Code == 160 && version < DxfVersion.AutoCad2010) |
| [ValidateEntityCommonDataVersion](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfEntityCommonData.cs#L99-L106) |  |  | data.ColorName != null && version < DxfVersion.AutoCad2004; data.ShadowMode.HasValue && version < DxfVersion.AutoCad2007 |
| [WriteEntityCommonData](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfEntityCommonData.cs#L108-L126) |  | 92, 160, 284, 310, 430 | this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2013 |

## netDxf/IO/DxfGroupCode.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfHatchBoundaryExport.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfHatchScalarEdge.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfHatchSourceRelations.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfHatchSplineData.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfHatchSplineFitVersion.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ValidateHatchSplineFitVersions](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfHatchSplineFitVersion.cs#L35-L58) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2010 |

## netDxf/IO/DxfHelix.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ValidateHelixVersions](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfHelix.cs#L110-L117) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 |
| [WriteHelix](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfHelix.cs#L137-L149) |  | 10, 11, 12, 20, 21, 22, 30, 31, 32, 40, 41, 42, 90, 91, 100, 210, 220, 230, 280, 290 |  |

## netDxf/IO/DxfLight.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ValidateLightVersions](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfLight.cs#L89-L96) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 |
| [WriteLight](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfLight.cs#L98-L114) |  | 1, 10, 11, 20, 21, 30, 31, 40, 41, 42, 50, 51, 70, 72, 73, 90, 91, 100, 280, 290, 291, 292, 293 |  |

## netDxf/IO/DxfLwPolyline.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadLwPolyline](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfLwPolyline.cs#L14-L138) | 10, 20, 38, 39, 40, 41, 42, 43, 70, 90, 91, 210, 220, 230, 1001 |  |  |
| [ValidateLwPolylineFidelity](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfLwPolyline.cs#L142-L157) |  |  | hasIdentifiers && this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2013 |

## netDxf/IO/DxfMTextBackground.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ValidateMTextBackgroundVersion](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfMTextBackground.cs#L67-L75) |  |  | version < DxfVersion.AutoCad2007; (background.Flags & MTextBackgroundFillFlags.TextFrame) != 0 && version < DxfVersion.AutoCad2018 |
| [ValidateMTextBackgroundVersions](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfMTextBackground.cs#L77-L88) |  |  | version >= DxfVersion.AutoCad2018 |
| [WriteMTextBackground](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfMTextBackground.cs#L90-L103) |  | 45, 63, 90, 421, 431, 441 |  |

## netDxf/IO/DxfMTextColumns.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ValidateMTextColumns](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfMTextColumns.cs#L237-L274) |  |  | text.DefinedHeight.HasValue && version < DxfVersion.AutoCad2007; columns.Storage == MTextColumnStorage.Embedded && version < DxfVersion.AutoCad2018; columns.Storage == MTextColumnStorage.LegacyLinked && version >= DxfVersion.AutoCad2018; columns.Storage == MTextColumnStorage.Direct && version < DxfVersion.AutoCad2007 |
| [WriteMTextColumnDefinition](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfMTextColumns.cs#L276-L307) |  | 10, 11, 20, 21, 30, 31, 40, 41, 42, 43, 44, 45, 46, 48, 49, 50, 70, 71, 72, 73, 74, 75, 76, 78, 79, 101 | defined.HasValue && this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 |
| [WriteMTextColumnXData](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfMTextColumns.cs#L309-L344) |  |  | defined.HasValue && this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2018 &&                 (c == null \|\| c.Type != MTextColumnType.Dynamic \|\| c.AutoHeight) |

## netDxf/IO/DxfMeshVersion.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ValidateMeshVersions](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfMeshVersion.cs#L35-L49) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2010 |

## netDxf/IO/DxfMeshWriteValidation.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfOle2Frame.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteOle2Frame](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfOle2Frame.cs#L102-L129) |  | 1, 3, 10, 11, 20, 21, 30, 31, 70, 71, 72, 90, 100, 310 |  |

## netDxf/IO/DxfOleFrame.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteOleFrame](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfOleFrame.cs#L72-L86) |  | 1, 70, 90, 100, 310 |  |

## netDxf/IO/DxfRawDocument.AtomicSave.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawDocument.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [Load](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfRawDocument.cs#L95-L124) |  |  | binary && legacyGroupCodes != (version < DxfVersion.AutoCad13) |
| [ResolveEncoding](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfRawDocument.cs#L515-L539) |  |  | version >= DxfVersion.AutoCad2007 |

## netDxf/IO/DxfRawHandleIndex.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawHandleModel.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawHandleOperations.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawObjectCommit.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [UpdateClasses](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfRawObjectCommit.cs#L126-L176) |  |  | this.store.Document.Version >= DxfVersion.AutoCad2004; this.store.Document.Version >= DxfVersion.AutoCad2004 |

## netDxf/IO/DxfRawObjectGraph.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [SetDrawOrder](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfRawObjectGraph.cs#L123-L160) |  |  | this.store.Document.Version < DxfVersion.AutoCad2004 |

## netDxf/IO/DxfRawObjectModel.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawObjectStore.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawObjectTransaction.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawOptions.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawRecord.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawSection.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfRawTagContext.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.Containers.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadSpatialFilterPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.Containers.cs#L49-L92) | 10, 11, 20, 21, 30, 31, 40, 41, 70, 71, 72, 73, 210, 220, 230 |  |  |

## netDxf/IO/DxfReader.DataTable.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadDataTablePayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.DataTable.cs#L71-L139) |  |  | this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2004 |

## netDxf/IO/DxfReader.DatabaseMetadata.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.DeclaredOwnership.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.Defaults.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.GeoData.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadGeoDataPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.GeoData.cs#L15-L86) |  |  | this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2010 \|\| payload.Count == 0 \|\| payload[0].Code != 100 \|\| (string)payload[0].Value != "AcDbGeoData" |

## netDxf/IO/DxfReader.HeaderProbe.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.LayerFilterPointer.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.LayerIndex.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.LightList.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadLightListPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.LightList.cs#L12-L44) |  |  | type != "LIGHTLIST" \|\| this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2007 |

## netDxf/IO/DxfReader.MultiLeader.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.Objects.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadDatabaseRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.Objects.cs#L29-L223) | 3, 280, 281, 340, 350, 360 |  |  |

## netDxf/IO/DxfReader.OpaqueEntity.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadOpaqueCommon](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.OpaqueEntity.cs#L218-L271) | 6, 8, 48, 60, 62, 67, 92, 160, 284, 310, 370, 420, 430, 440 |  |  |

## netDxf/IO/DxfReader.OutputSettings.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ParsePlotSettings](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.OutputSettings.cs#L35-L87) | 1, 2, 4, 6, 7, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 70, 72, 73, 74, 75, 76, 77, 78, 140, 141, 142, 143, 147, 148, 149, 333 |  |  |

## netDxf/IO/DxfReader.PolyfaceMeshRecords.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadStoredPolyfaceMesh](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.PolyfaceMeshRecords.cs#L13-L101) | 10, 20, 30, 66, 70, 71, 72, 75, 210, 220, 230 |  |  |

## netDxf/IO/DxfReader.PolygonMeshRecords.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.Polyline2DRecords.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadStoredPolyline2D](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.Polyline2DRecords.cs#L13-L94) | 10, 20, 30, 39, 40, 41, 66, 70, 75, 210, 220, 230 |  |  |

## netDxf/IO/DxfReader.PolylineRecords.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.PrivateXRecord.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.Section.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadSection](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.Section.cs#L14-L34) |  |  | this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2007 |

## netDxf/IO/DxfReader.SectionManager.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadSectionManagerRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.SectionManager.cs#L14-L46) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 && tags.All(tag => tag.Code != 100) |

## netDxf/IO/DxfReader.SectionSettings.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadSectionSettingsRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.SectionSettings.cs#L24-L68) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 && (start >= end \|\| tags[start].Code != 100); opaque.Count == 0 && this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 |

## netDxf/IO/DxfReader.SourceIdentity.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.StoredCellStyleMap.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.StoredDimAssoc.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.StoredEnvelopes.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.StoredField.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.StoredSunStudy.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.StoredTable.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.StoredTableContent.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadStoredTableContentRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.StoredTableContent.cs#L13-L42) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2004 && subclasses.Length != 0                 && subclasses.All(DxfStoredTableContent.SubclassNames.Contains) && body.All(tag => tag.Code != 102)                 && !subclasses.SequenceEqual(DxfStoredTableContent.SubclassNames) |

## netDxf/IO/DxfReader.StoredTableGeometry.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.Sun.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadSunPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.Sun.cs#L89-L130) |  |  | this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2007 |

## netDxf/IO/DxfReader.TableStyle.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.UcsBase.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfReader.Views.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [ReadView](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.Views.cs#L35-L129) | 2, 10, 11, 12, 20, 21, 22, 31, 32, 40, 41, 42, 43, 44, 50, 70, 71, 73, 281, 334, 361, 1001 |  |  |

## netDxf/IO/DxfReader.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [Read](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L150-L369) |  |  | version < DxfVersion.AutoCad2000; version < DxfVersion.AutoCad2007 |
| [ReadHeader](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L375-L723) |  |  | acadVer < DxfVersion.AutoCad2000 |
| [ReadHeaderVector](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L725-L750) | 10, 20, 30 |  |  |
| [ReadBlocks](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L893-L957) |  |  |  |
| [ReadObjects](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L970-L1100) |  |  |  |
| [ReadTable](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L1127-L1263) | 5, 100, 102, 330, 1001 |  |  |
| [ReadTableEntry](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L1265-L1407) | 5, 102, 105, 330 |  |  |
| [ReadApplicationId](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L1409-L1446) | 2, 1001 |  |  |
| [ReadBlockRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L1448-L1591) | 2, 70, 280, 281, 340, 1001 |  |  |
| [ReadDimensionStyle](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L1593-L2253) | 2, 3, 4, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 140, 141, 142, 143, 144, 145, 146, 147, 148, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 288, 289, 290, 294, 340, 341, 342, 343, 344, 345, 346, 347, 371, 372, 1001 |  |  |
| [ReadLayer](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L2345-L2452) | 2, 6, 62, 70, 290, 370, 420, 1001 |  |  |
| [ReadLinetype](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L2454-L2541) | 2, 3, 40, 49, 73, 1001 |  |  |
| [ReadLinetypeComplexSegment](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L2543-L2615) | 9, 44, 45, 46, 50, 75, 340 |  |  |
| [ReadUCS](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L2695-L2841) | 2, 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 70, 71, 79, 146, 346, 1001 |  |  |
| [ReadBlock](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L2859-L3075) | 1, 2, 3, 4, 5, 8, 10, 20, 30, 70, 1001 |  |  |
| [ReadAttributeDefinition](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L3077-L3264) | 1, 2, 3, 7, 10, 11, 20, 21, 30, 31, 40, 41, 50, 51, 70, 71, 72, 74, 210, 220, 230, 1001 |  |  |
| [ReadAttribute](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L3266-L3569) | 0, 1, 2, 5, 6, 7, 8, 10, 11, 20, 21, 30, 31, 40, 41, 48, 50, 51, 60, 62, 70, 71, 72, 74, 92, 160, 210, 220, 230, 284, 310, 370, 420, 430, 440, 1001 |  |  |
| [ReadEntity](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L3575-L3878) | 0, 5, 6, 8, 48, 60, 62, 92, 102, 160, 284, 310, 330, 370, 420, 430, 440 |  |  |
| [ReadWipeout](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L3880-L3988) | 10, 11, 12, 14, 20, 21, 22, 24, 30, 31, 32, 71, 91, 1001 |  |  |
| [ReadUnderlay](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L3990-L4134) | 10, 11, 20, 21, 30, 41, 42, 43, 50, 210, 220, 230, 280, 281, 282, 340, 1001 |  |  |
| [ReadTolerance](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L4136-L4240) | 1, 3, 10, 11, 20, 21, 30, 31, 210, 220, 230, 1001 |  |  |
| [ReadLeader](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L4344-L4483) | 3, 10, 71, 72, 73, 74, 75, 76, 77, 210, 211, 213, 220, 221, 223, 230, 231, 233, 340, 1001 |  |  |
| [ReadMesh](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L4505-L4625) | 10, 20, 30, 71, 72, 90, 91, 92, 93, 94, 95, 140, 1001 |  |  |
| [ReadViewport](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L4736-L4954) | 10, 12, 13, 14, 15, 16, 17, 20, 22, 23, 24, 25, 26, 27, 30, 36, 37, 40, 41, 42, 43, 44, 45, 50, 51, 68, 69, 72, 90, 110, 111, 112, 120, 121, 122, 130, 131, 132, 331, 340, 361, 1001 |  |  |
| [ReadImage](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L4956-L5123) | 10, 11, 12, 13, 14, 20, 21, 22, 23, 24, 30, 31, 32, 70, 71, 91, 280, 281, 282, 283, 340, 1001 |  |  |
| [ReadArc](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L5125-L5212) | 10, 20, 30, 39, 40, 50, 51, 210, 220, 230, 1001 |  |  |
| [ReadCircle](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L5214-L5288) | 10, 20, 30, 39, 40, 210, 220, 230, 1001 |  |  |
| [ReadDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L5290-L5493) | 1, 2, 3, 10, 11, 20, 21, 30, 31, 41, 51, 53, 70, 71, 72, 100, 210, 220, 230 |  |  |
| [ReadAlignedDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6319-L6385) | 13, 14, 23, 24, 33, 34, 1001 |  |  |
| [ReadLinearDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6387-L6463) | 13, 14, 23, 24, 33, 34, 50, 52, 1001 |  |  |
| [ReadRadialDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6465-L6520) | 15, 25, 35, 40, 1001 |  |  |
| [ReadDiametricDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6522-L6578) | 15, 25, 35, 40, 1001 |  |  |
| [ReadAngular3PointDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6580-L6660) | 13, 14, 15, 23, 24, 25, 33, 34, 35, 1001 |  |  |
| [ReadAngular2LineDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6662-L6765) | 13, 14, 15, 16, 23, 24, 25, 26, 33, 34, 35, 36, 1001 |  |  |
| [ReadOrdinateDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6767-L6835) | 13, 14, 23, 24, 33, 34, 1001 |  |  |
| [ReadArcLengthDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6837-L6919) | 13, 14, 15, 23, 24, 25, 33, 34, 35, 1001 |  |  |
| [ReadEllipse](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L6921-L7013) | 10, 11, 20, 21, 30, 31, 40, 41, 42, 210, 220, 230, 1001 |  |  |
| [ReadPoint](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L7043-L7111) | 10, 20, 30, 39, 50, 210, 220, 230, 1001 |  |  |
| [ReadFace3d](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L7113-L7203) | 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 70, 1001 |  |  |
| [ReadShape](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L7205-L7327) | 2, 10, 20, 30, 39, 40, 41, 50, 51, 210, 220, 230, 1001 |  |  |
| [ReadSolid](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L7329-L7434) | 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 39, 210, 220, 230, 1001 |  |  |
| [ReadTrace](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L7436-L7541) | 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 39, 210, 220, 230, 1001 |  |  |
| [ReadSpline](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L7543-L7786) | 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 40, 41, 42, 43, 44, 70, 71, 72, 73, 74, 210, 220, 230, 1001 |  |  |
| [ReadInsert](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L7788-L7934) | 2, 10, 20, 30, 41, 42, 43, 44, 45, 50, 70, 71, 210, 220, 230, 1001 |  |  |
| [ReadLine](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L7936-L8012) | 10, 11, 20, 21, 30, 31, 39, 210, 220, 230, 1001 |  |  |
| [ReadRay](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L8014-L8070) | 10, 11, 20, 21, 30, 31, 1001 |  |  |
| [ReadXLine](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L8072-L8128) | 10, 11, 20, 21, 30, 31, 1001 |  |  |
| [ReadMLine](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L8130-L8233) | 2, 10, 11, 20, 30, 40, 70, 71, 72, 73, 210, 220, 230, 1001 |  |  |
| [ReadPolyline](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L8516-L8682) | 5, 8, 30, 39, 70, 71, 72, 73, 74, 75, 210, 220, 230, 1001 |  |  |
| [ReadVertex](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L8684-L8827) | 5, 6, 8, 10, 20, 30, 40, 41, 42, 62, 70, 71, 72, 73, 74, 420 |  |  |
| [ReadText](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L8829-L9010) | 1, 7, 10, 11, 20, 21, 30, 31, 40, 41, 50, 51, 71, 72, 73, 210, 220, 230, 1001 |  |  |
| [ReadMText](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L9012-L9203) | 1, 3, 7, 10, 11, 20, 21, 30, 31, 40, 41, 44, 50, 71, 72, 73, 101, 210, 220, 230, 1001 |  |  |
| [ReadHatch](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L9205-L9394) | 2, 30, 41, 43, 44, 45, 46, 47, 49, 52, 53, 63, 70, 71, 75, 76, 77, 78, 79, 91, 92, 93, 98, 210, 220, 230, 421, 450, 451, 452, 453, 460, 461, 462, 463, 470, 1001 |  |  |
| [ReadHatchSplineEdge](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L9560-L9607) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2010 |
| [ReadHatchGradientTag](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L9735-L9791) | 63, 421, 450, 451, 452, 453, 460, 461, 462, 463, 470 |  |  |
| [ReadHatchPatternDefinitionLine](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L9836-L9899) | 43, 44, 45, 46, 79 |  |  |
| [CreateObjectCollection](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L9960-L10006) |  |  |  |
| [ReadRasterVariables](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L10008-L10050) | 5, 70, 71, 72, 1001 |  |  |
| [ReadImageDefinition](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L10052-L10178) | 1, 5, 10, 11, 20, 21, 102, 281, 330, 1001 |  |  |
| [ReadImageDefReactor](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L10180-L10208) | 5, 330 |  |  |
| [ReadMLineStyle](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L10210-L10303) | 2, 3, 5, 51, 52, 62, 70, 71, 420, 1001 |  |  |
| [ReadGroup](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L10346-L10443) | 5, 70, 71, 300, 330, 340, 1001 |  |  |
| [ReadLayout](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L10445-L10667) | 0, 1, 5, 10, 11, 12, 13, 14, 15, 16, 17, 20, 21, 22, 23, 24, 25, 26, 27, 32, 33, 34, 35, 36, 37, 71, 100, 102, 146, 330, 1001 |  |  |
| [ReadUnderlayDefinition](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L10685-L10814) | 1, 2, 5, 330, 1001 |  |  |
| [BuildLayerStateManager](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L11063-L11171) | 8, 290, 301, 302, 330 |  |  |
| [ReadLayerStateProperties](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L11173-L11238) | 1, 6, 62, 90, 92, 331, 370, 440 |  |  |
| [ReadExtensionDictionaryGroup](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfReader.cs#L11326-L11348) | 360 |  |  |

## netDxf/IO/DxfTag.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfTagSlice.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfThumbnailImage.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [Read](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfThumbnailImage.cs#L35-L100) | 90, 310, 999 |  |  |
| [Write](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfThumbnailImage.cs#L102-L131) |  | 0, 2, 90, 310 |  |

## netDxf/IO/DxfVPort.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteVPort](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfVPort.cs#L159-L219) |  | 0, 2, 5, 10, 11, 12, 13, 14, 15, 16, 17, 20, 21, 22, 23, 24, 25, 26, 27, 36, 37, 40, 41, 42, 43, 44, 50, 51, 65, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 100, 110, 111, 112, 120, 121, 122, 130, 131, 132, 146, 281, 330, 345, 346 |  |

## netDxf/IO/DxfVersionNotSupportedException.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfViewSection.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfViewUcs.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteViewUcs](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfViewUcs.cs#L115-L125) |  | 72, 79, 110, 111, 112, 120, 121, 122, 130, 131, 132, 146, 345, 346 |  |

## netDxf/IO/DxfWriter.Containers.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteContainerPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Containers.cs#L7-L35) |  | 5, 10, 20, 40, 41, 70, 71, 72, 73, 100, 330, 331 |  |
| [WriteContainerVector](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Containers.cs#L36-L37) |  |  (+ dynamic codes; see JSON) |  |
| [WriteContainerMatrix](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Containers.cs#L38-L39) |  | 40 |  |

## netDxf/IO/DxfWriter.DataTable.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteDataTablePayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.DataTable.cs#L14-L44) |  | 1, 2, 3, 40, 70, 71, 90, 91, 92, 93, 100 (+ dynamic codes; see JSON) |  |

## netDxf/IO/DxfWriter.DimensionStyleParity.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteStoredDimensionHeader](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.DimensionStyleParity.cs#L44-L49) |  | 9 (+ dynamic codes; see JSON) |  |

## netDxf/IO/DxfWriter.GeoData.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteGeoDataPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.GeoData.cs#L24-L50) |  | 12, 13, 14, 22, 23, 24, 40, 41, 70, 90, 91, 92, 93, 95, 96, 97, 98, 99, 100, 141, 142, 143, 294, 302, 305, 306, 307, 330 (+ dynamic codes; see JSON) |  |
| [WriteGeoVector](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.GeoData.cs#L51-L52) |  |  (+ dynamic codes; see JSON) |  |

## netDxf/IO/DxfWriter.LayerFilterPointer.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteLayerFilterPointerPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.LayerFilterPointer.cs#L41-L51) |  | 8, 100 |  |

## netDxf/IO/DxfWriter.LayerIndex.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteLayerIndexPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.LayerIndex.cs#L14-L26) |  | 8, 40, 90, 100, 360 |  |

## netDxf/IO/DxfWriter.LightList.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteLightListPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.LightList.cs#L26-L38) |  | 1, 5, 90, 100 |  |

## netDxf/IO/DxfWriter.MultiLeader.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteMLeaderVector](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.MultiLeader.cs#L38-L39) |  |  (+ dynamic codes; see JSON) |  |
| [WriteMLeaderFields](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.MultiLeader.cs#L40-L51) |  |  (+ dynamic codes; see JSON) |  |
| [WriteMultiLeader](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.MultiLeader.cs#L52-L60) |  | 100, 270 |  |
| [WriteMLeaderContext](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.MultiLeader.cs#L61-L91) |  | 47, 90, 144, 290, 295, 296, 300, 301, 302, 303, 304, 305 |  |
| [WriteMLeaderStylePayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.MultiLeader.cs#L92-L96) |  | 100, 179 |  |

## netDxf/IO/DxfWriter.Objects.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteDatabaseMetadata](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Objects.cs#L47-L70) |  | 102, 330, 360 |  |
| [WriteDatabaseObject](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Objects.cs#L104-L167) |  | 0, 1, 3, 5, 100, 280, 281, 330, 340, 350 (+ dynamic codes; see JSON) |  |
| [WriteDatabaseTag](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Objects.cs#L168-L173) |  |  (+ dynamic codes; see JSON) |  |

## netDxf/IO/DxfWriter.OpaqueEntity.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteOpaqueEntity](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.OpaqueEntity.cs#L57-L60) |  |  (+ dynamic codes; see JSON) |  |

## netDxf/IO/DxfWriter.OutputSettings.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteOutputSettingsPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.OutputSettings.cs#L28-L34) |  | 70, 100 |  |
| [WritePlotSettingsPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.OutputSettings.cs#L35-L49) |  | 1, 2, 4, 6, 7, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 70, 72, 73, 74, 75, 76, 77, 78, 100, 140, 141, 142, 143, 147, 148, 149, 333 |  |

## netDxf/IO/DxfWriter.PolyfaceMesh.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.PolyfaceMeshRecords.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteStoredPolyfaceMeshHeader](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolyfaceMeshRecords.cs#L33-L49) |  | 210, 220, 230 (+ dynamic codes; see JSON) |  |
| [WriteStoredPolyfaceMeshRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolyfaceMeshRecords.cs#L51-L116) |  | 0, 5, 8, 62, 330, 420 (+ dynamic codes; see JSON) |  |
| [WritePolyfaceMeshExtension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolyfaceMeshRecords.cs#L117-L121) |  | 102, 360 |  |
| [WritePolyfaceMeshReactors](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolyfaceMeshRecords.cs#L122-L128) |  | 102, 330 |  |

## netDxf/IO/DxfWriter.PolygonMeshRecords.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteStoredPolygonMeshRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolygonMeshRecords.cs#L45-L85) |  | 0, 5, 330 (+ dynamic codes; see JSON) |  |
| [WritePolygonMeshExtension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolygonMeshRecords.cs#L86-L90) |  | 102, 360 |  |
| [WritePolygonMeshReactors](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolygonMeshRecords.cs#L91-L97) |  | 102, 330 |  |

## netDxf/IO/DxfWriter.Polyline2DRecords.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteStoredPolyline2DRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Polyline2DRecords.cs#L49-L94) |  | 0, 5, 330 (+ dynamic codes; see JSON) |  |
| [WritePolyline2DExtension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Polyline2DRecords.cs#L95-L99) |  | 102, 360 |  |
| [WritePolyline2DReactors](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Polyline2DRecords.cs#L100-L106) |  | 102, 330 |  |

## netDxf/IO/DxfWriter.PolylineRecords.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteStoredPolylineRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolylineRecords.cs#L29-L69) |  | 0, 5, 330 (+ dynamic codes; see JSON) |  |
| [WritePolylineExtension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolylineRecords.cs#L70-L74) |  | 102, 360 |  |
| [WritePolylineReactors](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.PolylineRecords.cs#L75-L81) |  | 102, 330 |  |

## netDxf/IO/DxfWriter.Section.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteSection](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Section.cs#L45-L57) |  | 1, 40, 41, 62, 63, 70, 90, 91, 92, 93, 100, 360, 411 |  |

## netDxf/IO/DxfWriter.SectionManager.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.SectionSettings.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteSectionSettingsPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.SectionSettings.cs#L9-L37) |  | 1, 2, 3, 6, 8, 40, 41, 42, 43, 70, 71, 72, 90, 91, 92, 93, 100, 330, 331, 370 (+ dynamic codes; see JSON) | this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2007 |

## netDxf/IO/DxfWriter.StoredCellStyleMap.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.StoredDimAssoc.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.StoredEnvelopes.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteStoredEnvelopePayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.StoredEnvelopes.cs#L10-L23) |  | 40, 90, 100, 310 |  |

## netDxf/IO/DxfWriter.StoredField.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.StoredSunStudy.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.StoredTable.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteStoredTable](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.StoredTable.cs#L30-L38) |  |  (+ dynamic codes; see JSON) |  |

## netDxf/IO/DxfWriter.StoredTableContent.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.StoredTableGeometry.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.Sun.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteSunPayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Sun.cs#L11-L28) |  | 40, 63, 70, 71, 90, 91, 92, 100, 280, 290, 291, 292, 421 |  |
| [WriteSunReference](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Sun.cs#L29-L34) |  | 361 |  |

## netDxf/IO/DxfWriter.TableStyle.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteTableStylePayload](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.TableStyle.cs#L11-L21) |  |  (+ dynamic codes; see JSON) |  |

## netDxf/IO/DxfWriter.TextStyle.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/DxfWriter.Views.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [WriteView](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.Views.cs#L35-L74) |  | 0, 2, 5, 10, 11, 12, 20, 21, 22, 31, 32, 40, 41, 42, 43, 44, 50, 70, 71, 73, 100, 281, 330, 334 | view.IsCameraPlottable && this.doc.DrawingVariables.AcadVer < DxfVersion.AutoCad2007; this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 |

## netDxf/IO/DxfWriter.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|
| [Write](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L80-L542) |  | 9, 10, 20, 30 (+ dynamic codes; see JSON) | version < DxfVersion.AutoCad2000 |
| [Close](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L551-L555) |  | 0 |  |
| [BeginSection](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L562-L569) |  | 0, 2 |  |
| [EndSection](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L574-L580) |  | 0 |  |
| [BeginTable](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L589-L617) |  | 0, 2, 5, 70, 100, 102, 330, 360 |  |
| [EndTable](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L622-L628) |  | 0 |  |
| [WriteComment](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L634-L640) |  | 999 |  |
| [WriteSystemVariable](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L642-L819) |  | 1, 2, 3, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 62, 70, 290, 370 | this.doc.DrawingVariables.AcadVer <= DxfVersion.AutoCad2000 |
| [WriteActiveDimensionStyleSystemVariables](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L821-L1155) |  | 1, 6, 9, 40, 70 |  |
| [WriteApplicationRegistry](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1165-L1182) |  | 0, 2, 5, 70, 100, 330 |  |
| [WriteDimensionStyle](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1188-L1400) |  | 0, 2, 3, 4, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 100, 105, 140, 141, 142, 143, 144, 145, 146, 147, 148, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 288, 289, 290, 294, 330, 340, 341, 342, 343, 344, 345, 346, 347, 371, 372 |  |
| [WriteBlockRecord](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1406-L1438) |  | 0, 2, 5, 70, 100, 280, 281, 330, 340 |  |
| [WriteLinetype](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1466-L1541) |  | 0, 2, 3, 5, 9, 40, 44, 45, 46, 49, 50, 70, 72, 73, 74, 75, 100, 330, 340 |  |
| [WriteLayer](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1547-L1608) |  | 0, 2, 5, 6, 62, 70, 100, 290, 330, 370, 390, 420 |  |
| [WriteTextStyle](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1656-L1687) |  | 0, 2, 3, 4, 5, 40, 41, 42, 50, 70, 71, 100, 330 |  |
| [WriteShapeStyle](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1693-L1717) |  | 0, 2, 3, 5, 40, 41, 42, 50, 70, 71, 100, 330 |  |
| [WriteUCS](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1723-L1769) |  | 0, 2, 5, 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 70, 71, 79, 100, 146, 330, 346 |  |
| [WriteBlock](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1775-L1850) |  | 0, 1, 2, 3, 4, 5, 8, 10, 20, 30, 67, 70, 100, 330 |  |
| [WriteEntity](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L1856-L2012) |  |  |  |
| [WriteEntityCommonCodes](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2014-L2049) |  | 0, 5, 6, 8, 48, 60, 62, 67, 100, 330, 370, 420, 440 |  |
| [WriteWipeout](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2051-L2119) |  | 10, 11, 12, 13, 14, 20, 21, 22, 23, 24, 30, 31, 32, 71, 91, 100, 280, 281, 282, 283 |  |
| [WriteUnderlay](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2121-L2157) |  | 10, 11, 20, 21, 30, 41, 42, 43, 50, 100, 210, 220, 230, 280, 281, 282, 340 |  |
| [WriteTolerance](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2159-L2187) |  | 1, 3, 10, 11, 20, 21, 30, 31, 100, 210, 220, 230 |  |
| [WriteLeader](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2210-L2298) |  | 3, 10, 20, 30, 71, 72, 73, 74, 75, 76, 77, 100, 210, 211, 213, 220, 221, 223, 230, 231, 233, 340 |  |
| [WriteMesh](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2300-L2356) |  | 10, 20, 30, 71, 72, 90, 91, 92, 93, 94, 95, 100, 140 |  |
| [WriteShape](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2358-L2380) |  | 2, 10, 20, 30, 39, 40, 41, 50, 51, 100, 210, 220, 230 |  |
| [WriteArc](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2382-L2408) |  | 10, 20, 30, 39, 40, 50, 51, 100, 210, 220, 230 |  |
| [WriteCircle](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2410-L2432) |  | 10, 20, 30, 39, 40, 100, 210, 220, 230 |  |
| [WriteEllipse](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2434-L2461) |  | 10, 11, 20, 21, 30, 31, 40, 41, 42, 100, 210, 220, 230 |  |
| [WriteSolid](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2484-L2512) |  | 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 39, 100, 210, 220, 230 |  |
| [WriteTrace](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2514-L2542) |  | 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 39, 100, 210, 220, 230 |  |
| [WriteFace3D](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2544-L2567) |  | 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 70, 100 |  |
| [WriteSpline](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2569-L2641) |  | 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 40, 41, 42, 43, 44, 70, 71, 100 |  |
| [WriteInsert](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2643-L2700) |  | 0, 2, 5, 8, 10, 20, 30, 41, 42, 43, 44, 45, 50, 66, 70, 71, 100, 210, 220, 230 |  |
| [WriteLine](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2702-L2721) |  | 10, 11, 20, 21, 30, 31, 39, 100, 210, 220, 230 |  |
| [WriteRay](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2723-L2736) |  | 10, 11, 20, 21, 30, 31, 100 |  |
| [WriteXLine](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2738-L2751) |  | 10, 11, 20, 21, 30, 31, 100 |  |
| [WriteLwPolyline](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2753-L2779) |  | 10, 20, 38, 39, 40, 41, 42, 43, 70, 90, 91, 100, 210, 220, 230 |  |
| [WritePolyline](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2781-L2877) |  | 0, 5, 8, 10, 20, 30, 40, 41, 62, 70, 71, 72, 73, 74, 75, 100, 210, 220, 230, 330, 420 (+ dynamic codes; see JSON) |  |
| [WritePoint](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2879-L2897) |  | 10, 20, 30, 39, 50, 100, 210, 220, 230 |  |
| [WriteText](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L2899-L3035) |  | 1, 7, 10, 11, 20, 21, 30, 31, 40, 41, 50, 51, 71, 72, 73, 100, 210, 220, 230 |  |
| [WriteMText](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3037-L3080) |  | 7, 10, 11, 20, 21, 30, 31, 40, 41, 44, 71, 72, 73, 100, 210, 220, 230 |  |
| [WriteMTextChunks](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3082-L3096) |  | 1, 3 |  |
| [WriteHatch](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3098-L3123) |  | 2, 10, 20, 30, 70, 71, 100, 210, 220, 230 |  |
| [WriteHatchBoundaryPaths](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3160-L3185) |  | 91, 92, 93, 97, 330 |  |
| [WriteHatchBoundaryPathData](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3187-L3295) |  | 10, 11, 12, 13, 20, 21, 22, 23, 40, 42, 50, 51, 72, 73, 74, 93, 94, 95, 96, 97 | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2010 |
| [WriteHatchPattern](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3297-L3330) |  | 10, 20, 41, 47, 52, 75, 76, 77, 78, 98 | this.doc.DrawingVariables.AcadVer <= DxfVersion.AutoCad2000 |
| [WriteGradientHatchPattern](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3332-L3353) |  | 63, 421, 450, 451, 452, 453, 460, 461, 462, 463, 470 |  |
| [WriteHatchPatternDefinitionLines](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3355-L3385) |  | 43, 44, 45, 46, 49, 53, 79 |  |
| [WriteDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3387-L3466) |  | 1, 2, 3, 10, 11, 20, 21, 30, 31, 41, 51, 53, 70, 71, 72, 100, 210, 220, 230 |  |
| [WriteAlignedDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L3991-L4006) |  | 13, 14, 23, 24, 33, 34, 100 |  |
| [WriteLinearDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4008-L4030) |  | 13, 14, 23, 24, 33, 34, 50, 100 |  |
| [WriteRadialDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4032-L4045) |  | 15, 25, 35, 40, 100 |  |
| [WriteDiametricDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4047-L4060) |  | 15, 25, 35, 40, 100 |  |
| [WriteAngular3PointDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4062-L4083) |  | 13, 14, 15, 23, 24, 25, 33, 34, 35, 100 |  |
| [WriteAngular2LineDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4085-L4110) |  | 13, 14, 15, 16, 23, 24, 25, 26, 33, 34, 35, 36, 100 |  |
| [WriteOrdinateDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4112-L4127) |  | 13, 14, 23, 24, 33, 34, 100 |  |
| [WriteArcLengthDimension](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4129-L4152) |  | 13, 14, 15, 23, 24, 25, 33, 34, 35, 100 |  |
| [WriteImage](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4154-L4214) |  | 10, 11, 12, 13, 14, 20, 21, 22, 23, 24, 30, 31, 32, 70, 71, 91, 100, 280, 281, 282, 283, 340, 360 |  |
| [WriteMLine](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4216-L4288) |  | 2, 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 40, 41, 70, 71, 72, 73, 74, 75, 100, 210, 220, 230, 340 |  |
| [WriteAttributeDefinition](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4290-L4468) |  | 0, 1, 2, 3, 5, 6, 7, 8, 10, 11, 20, 21, 30, 31, 40, 41, 48, 50, 51, 60, 62, 67, 70, 71, 72, 74, 100, 210, 220, 230, 330, 370, 420, 440 |  |
| [WriteAttribute](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4470-L4633) |  | 0, 1, 2, 5, 6, 7, 8, 10, 11, 20, 21, 30, 31, 40, 41, 48, 50, 51, 60, 62, 70, 71, 72, 74, 100, 210, 220, 230, 330, 370, 420, 440 |  |
| [WriteViewport](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4635-L4704) |  | 10, 12, 13, 14, 15, 16, 17, 20, 22, 23, 24, 25, 26, 27, 30, 36, 37, 40, 41, 42, 43, 44, 45, 50, 51, 68, 69, 72, 90, 100, 110, 111, 112, 120, 121, 122, 130, 131, 132, 331, 340 |  |
| [WriteDictionary](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4710-L4734) |  | 0, 3, 5, 100, 280, 281, 330 (+ dynamic codes; see JSON) |  |
| [WriteUnderlayDefinition](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4736-L4781) |  | 0, 1, 2, 5, 100, 330 |  |
| [WriteImageDefReactor](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4783-L4793) |  | 0, 5, 90, 100, 330 |  |
| [WriteImageDef](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4795-L4824) |  | 0, 1, 5, 10, 11, 20, 21, 100, 280, 281, 330 |  |
| [WriteRasterVariables](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4826-L4840) |  | 0, 5, 70, 71, 72, 90, 100, 330 |  |
| [WriteMLineStyle](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4842-L4878) |  | 0, 2, 3, 5, 6, 49, 51, 52, 62, 70, 71, 100, 330, 420 |  |
| [WriteGroup](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4880-L4899) |  | 0, 5, 70, 71, 100, 300, 330, 340 |  |
| [WriteLayout](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4901-L4952) |  | 0, 1, 5, 10, 11, 12, 13, 14, 15, 16, 17, 20, 21, 22, 23, 24, 25, 26, 27, 32, 33, 34, 35, 36, 37, 71, 76, 100, 146, 330 |  |
| [WriteLayerState](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4957-L4975) |  | 0, 5, 91, 100, 280, 290, 301, 302, 330 |  |
| [WriteLayerStateProperties](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L4977-L4998) |  | 62, 90, 92, 330, 331, 370, 440 |  |
| [PreprocessEntities](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L5004-L5030) |  |  |  |
| [EncodeNonAsciiCharacters](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L5409-L5450) |  |  | this.doc.DrawingVariables.AcadVer >= DxfVersion.AutoCad2007 |
| [WriteXDataRecords](https://github.com/wieslawsoltes/netDxf/blob/71b082eaa218f3db0742176d1fa97b0a14339900/netDxf/IO/DxfWriter.cs#L5458-L5493) |  |  (+ dynamic codes; see JSON) |  |

## netDxf/IO/HatchPatternXData.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/ICodeValueReader.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/ICodeValueWriter.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/TextCodeValueReader.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## netDxf/IO/TextCodeValueWriter.cs

| Method | Direct read cases on `.Code` | Direct literal write codes | Version conditions |
|---|---|---|---|

## Public properties: Entities

Declared properties only; inherited properties, methods and wire semantics are not inferred.

| Source | Public properties |
|---|---|
| netDxf/Entities/AcisEntity.cs | short ModelerFormatVersion { get; }; IReadOnlyList<AcisSatChunk> EncodedSatChunks { get; }; IReadOnlyList<string> SatLines { get; } |
| netDxf/Entities/AcisSatChunk.cs | short GroupCode { get; }; string Text { get; } |
| netDxf/Entities/AlignedDimension.cs | Vector2 FirstReferencePoint { get; set; }; Vector2 SecondReferencePoint { get; set; }; Vector2 DimLinePosition { get; }; double Offset { get; set; }; double Measurement { get; } |
| netDxf/Entities/Angular2LineDimension.cs | Vector2 CenterPoint { get; }; Vector2 StartFirstLine { get; set; }; Vector2 EndFirstLine { get; set; }; Vector2 StartSecondLine { get; set; }; Vector2 EndSecondLine { get; set; }; Vector2 ArcDefinitionPoint { get; set; }; double Offset { get; set; }; double Measurement { get; } |
| netDxf/Entities/Angular3PointDimension.cs | Vector2 CenterPoint { get; set; }; Vector2 StartPoint { get; set; }; Vector2 EndPoint { get; set; }; Vector2 ArcDefinitionPoint { get; }; double Offset { get; set; }; double Measurement { get; } |
| netDxf/Entities/Arc.cs | Vector3 Center { get; set; }; double Radius { get; set; }; double StartAngle { get; set; }; double EndAngle { get; set; }; double Thickness { get; set; } |
| netDxf/Entities/ArcLengthDimension.cs | Vector2 CenterPoint { get; set; }; double Radius { get; set; }; double StartAngle { get; set; }; double EndAngle { get; set; }; Vector2 ArcDefinitionPoint { get; }; double Offset { get; set; }; double ArcAngle { get; }; double Measurement { get; } |
| netDxf/Entities/Attribute.CommonData.cs | string ColorName { get; set; }; EntityShadowMode? ShadowMode { get; set; }; byte[] ProxyGraphics { get; set; } |
| netDxf/Entities/Attribute.cs | AciColor Color { get; set; }; Layer Layer { get; set; }; Linetype Linetype { get; set; }; Lineweight Lineweight { get; set; }; Transparency Transparency { get; set; }; double LinetypeScale { get; set; }; bool IsVisible { get; set; }; Vector3 Normal { get; set; }; Insert Owner { get; set; }; AttributeDefinition Definition { get; set; }; string Tag { get; }; double Height { get; set; }; double Width { get; set; }; double WidthFactor { get; set; }; double ObliqueAngle { get; set; }; string Value { get; set; }; TextStyle Style { get; set; }; Vector3 Position { get; set; }; AttributeFlags Flags { get; set; }; double Rotation { get; set; }; TextAlignment Alignment { get; set; }; bool IsBackward { get; set; }; bool IsUpsideDown { get; set; } |
| netDxf/Entities/AttributeChangeEventArgs.cs | Attribute Item { get; } |
| netDxf/Entities/AttributeDefinition.CommonData.cs | string ColorName { get; set; }; EntityShadowMode? ShadowMode { get; set; }; byte[] ProxyGraphics { get; set; } |
| netDxf/Entities/AttributeDefinition.cs | AciColor Color { get; set; }; Layer Layer { get; set; }; Linetype Linetype { get; set; }; Lineweight Lineweight { get; set; }; Transparency Transparency { get; set; }; double LinetypeScale { get; set; }; bool IsVisible { get; set; }; Vector3 Normal { get; set; }; string Tag { get; }; string Prompt { get; set; }; double Height { get; set; }; double Width { get; set; }; double WidthFactor { get; set; }; double ObliqueAngle { get; set; }; string Value { get; set; }; TextStyle Style { get; set; }; Vector3 Position { get; set; }; AttributeFlags Flags { get; set; }; double Rotation { get; set; }; TextAlignment Alignment { get; set; }; bool IsBackward { get; set; }; bool IsUpsideDown { get; set; }; Block Owner { get; set; } |
| netDxf/Entities/Circle.cs | Vector3 Center { get; set; }; double Radius { get; set; }; double Thickness { get; set; } |
| netDxf/Entities/DatumReferenceValue.cs | string Value { get; set; }; ToleranceMaterialCondition MaterialCondition { get; set; } |
| netDxf/Entities/DiametricDimension.cs | Vector2 CenterPoint { get; set; }; Vector2 ReferencePoint { get; set; }; double Measurement { get; } |
| netDxf/Entities/Dimension.cs | bool TextPositionManuallySet { get; set; }; Vector2 TextReferencePoint { get; set; }; DimensionStyle Style { get; set; }; DimensionStyleOverrideDictionary StyleOverrides { get; }; DimensionType DimensionType { get; }; double Measurement { get; }; MTextAttachmentPoint AttachmentPoint { get; set; }; MTextLineSpacingStyle LineSpacingStyle { get; set; }; double LineSpacingFactor { get; set; }; Block Block { get; set; }; double TextRotation { get; set; }; string UserText { get; set; }; double Elevation { get; set; } |
| netDxf/Entities/DimensionArrowhead.cs | Block Dot { get; }; Block DotSmall { get; }; Block DotBlank { get; }; Block OriginIndicator { get; }; Block OriginIndicator2 { get; }; Block Open { get; }; Block Open90 { get; }; Block Open30 { get; }; Block Closed { get; }; Block DotSmallBlank { get; }; Block None { get; }; Block Oblique { get; }; Block BoxFilled { get; }; Block Box { get; }; Block ClosedBlank { get; }; Block DatumTriangleFilled { get; }; Block DatumTriangle { get; }; Block Integral { get; }; Block ArchitecturalTick { get; } |
| netDxf/Entities/DxfOpaqueEntity.cs | DxfVersion SourceVersion { get; }; string SourceHandle { get; }; IReadOnlyList<DxfTag> SourceTags { get; }; IReadOnlyList<DxfObject> References { get; }; Vector3 Normal { get; set; } |
| netDxf/Entities/Ellipse.cs | Vector3 Center { get; set; }; double MajorAxis { get; }; double MinorAxis { get; }; double Rotation { get; set; }; double StartAngle { get; set; }; double EndAngle { get; set; }; double Thickness { get; set; }; bool IsFullEllipse { get; } |
| netDxf/Entities/EntityChangeEventArgs.cs | EntityObject Item { get; } |
| netDxf/Entities/EntityObject.CommonData.cs | string ColorName { get; set; }; EntityShadowMode? ShadowMode { get; set; }; byte[] ProxyGraphics { get; set; } |
| netDxf/Entities/EntityObject.cs | IReadOnlyList<DxfObject> Reactors { get; }; EntityType Type { get; }; AciColor Color { get; set; }; Layer Layer { get; set; }; Linetype Linetype { get; set; }; Lineweight Lineweight { get; set; }; Transparency Transparency { get; set; }; double LinetypeScale { get; set; }; bool IsVisible { get; set; }; Vector3 Normal { get; set; }; Block Owner { get; set; } |
| netDxf/Entities/Face3D.cs | Vector3 FirstVertex { get; set; }; Vector3 SecondVertex { get; set; }; Vector3 ThirdVertex { get; set; }; Vector3 FourthVertex { get; set; }; Face3DEdgeFlags EdgeFlags { get; set; } |
| netDxf/Entities/Hatch.cs | double? PixelSize { get; set; }; IList<Vector2> SeedPoints { get; }; HatchPattern Pattern { get; set; }; ObservableCollection<HatchBoundaryPath> BoundaryPaths { get; }; bool Associative { get; }; double Elevation { get; set; } |
| netDxf/Entities/HatchBoundaryPath.cs | IList<Vector2> FitPoints { get; }; Vector2? StartTangent { get; set; }; Vector2? EndTangent { get; set; }; IReadOnlyList<Edge> Edges { get; }; HatchBoundaryPathTypeFlags PathType { get; set; }; IReadOnlyList<EntityObject> Entities { get; } |
| netDxf/Entities/HatchGradientPattern.cs | HatchGradientPatternType GradientType { get; set; }; AciColor Color1 { get; set; }; AciColor Color2 { get; set; }; short? Color1AciIndex { get; set; }; short? Color2AciIndex { get; set; }; bool IsColor1AciIndexAutomatic { get; }; bool IsColor2AciIndexAutomatic { get; }; bool SingleColor { get; set; }; double Tint { get; set; }; double Shift { get; set; }; bool Centered { get; set; } |
| netDxf/Entities/HatchPattern.cs | HatchPattern Solid { get; }; HatchPattern Line { get; }; HatchPattern Net { get; }; HatchPattern Dots { get; }; string Name { get; }; string Description { get; set; }; HatchStyle Style { get; set; }; HatchType Type { get; set; }; bool IsDouble { get; set; }; HatchFillType Fill { get; set; }; Vector2 Origin { get; set; }; double Angle { get; set; }; double Scale { get; set; }; List<HatchPatternLineDefinition> LineDefinitions { get; } |
| netDxf/Entities/HatchPatternLineDefinition.cs | double Angle { get; set; }; Vector2 Origin { get; set; }; Vector2 Delta { get; set; }; List<double> DashPattern { get; } |
| netDxf/Entities/Helix.cs | int MajorReleaseNumber { get; set; }; int MaintenanceReleaseNumber { get; set; }; Vector3 AxisBasePoint { get; set; }; Vector3 StartPoint { get; set; }; Vector3 AxisVector { get; set; }; double Radius { get; set; }; double Turns { get; set; }; double TurnHeight { get; set; }; bool IsRightHanded { get; set; }; HelixConstraint Constraint { get; set; } |
| netDxf/Entities/Image.cs | Vector3 Position { get; set; }; Vector2 Uvector { get; set; }; Vector2 Vvector { get; set; }; double Height { get; set; }; double Width { get; set; }; double Rotation { get; set; }; ImageDefinition Definition { get; set; }; bool Clipping { get; set; }; short Brightness { get; set; }; short Contrast { get; set; }; short Fade { get; set; }; ImageDisplayFlags DisplayOptions { get; set; }; ClippingBoundary ClippingBoundary { get; set; } |
| netDxf/Entities/Insert.Array.cs | short ColumnCount { get; set; }; short RowCount { get; set; }; double ColumnSpacing { get; set; }; double RowSpacing { get; set; }; bool IsMultiple { get; }; int InstanceCount { get; } |
| netDxf/Entities/Insert.cs | DrawingUnits DefaultInsUnits { get; set; }; AttributeCollection Attributes { get; }; Block Block { get; set; }; Vector3 Position { get; set; }; Vector3 Scale { get; set; }; double Rotation { get; set; } |
| netDxf/Entities/Leader.cs | DimensionStyle Style { get; set; }; DimensionStyleOverrideDictionary StyleOverrides { get; }; bool ShowArrowhead { get; set; }; LeaderPathType PathType { get; set; }; List<Vector2> Vertexes { get; }; EntityObject Annotation { get; set; }; Vector2 Hook { get; set; }; bool HasHookline { get; set; }; AciColor LineColor { get; set; }; Vector3 Normal { get; set; }; double Elevation { get; set; }; Vector2 Offset { get; set; }; Vector2 Direction { get; set; } |
| netDxf/Entities/Light.cs | int VersionNumber { get; set; }; string Name { get; set; }; LightType LightType { get; set; }; bool IsOn { get; set; }; bool PlotGlyph { get; set; }; double Intensity { get; set; }; Vector3 Position { get; set; }; Vector3 Target { get; set; }; LightAttenuationType AttenuationType { get; set; }; bool UseAttenuationLimits { get; set; }; double AttenuationStartLimit { get; set; }; double AttenuationEndLimit { get; set; }; double HotspotAngle { get; set; }; double FalloffAngle { get; set; }; bool CastShadows { get; set; }; LightShadowType ShadowType { get; set; }; int ShadowMapSize { get; set; }; short ShadowMapSoftness { get; set; } |
| netDxf/Entities/Line.cs | Vector3 StartPoint { get; set; }; Vector3 EndPoint { get; set; }; Vector3 Direction { get; }; double Thickness { get; set; } |
| netDxf/Entities/LinearDimension.cs | Vector2 FirstReferencePoint { get; set; }; Vector2 SecondReferencePoint { get; set; }; Vector2 DimLinePosition { get; }; double Rotation { get; set; }; double Offset { get; set; }; double Measurement { get; } |
| netDxf/Entities/MLeaderArrowHead.Fields.cs | int Index { get; set; }; BlockRecord Block { get; set; } |
| netDxf/Entities/MLeaderBlockAttribute.Fields.cs | AttributeDefinition Definition { get; set; }; short Index { get; set; }; double Width { get; set; }; string Text { get; set; } |
| netDxf/Entities/MLeaderBlockContent.Fields.cs | BlockRecord Block { get; set; }; Vector3 Normal { get; set; }; Vector3 Position { get; set; }; Vector3 Scale { get; set; }; double Rotation { get; set; }; int Color { get; set; } |
| netDxf/Entities/MLeaderContext.Fields.cs | double Scale { get; set; }; Vector3 BasePoint { get; set; }; double TextHeight { get; set; }; double ArrowHeadSize { get; set; }; double LandingGap { get; set; }; short TextLeftAttachment { get; set; }; short TextRightAttachment { get; set; }; short TextAlignment { get; set; }; short BlockConnectionType { get; set; }; Vector3 PlaneOrigin { get; set; }; Vector3 PlaneXAxis { get; set; }; Vector3 PlaneYAxis { get; set; }; bool PlaneNormalReversed { get; set; }; short? TopAttachment { get; set; }; short? BottomAttachment { get; set; } |
| netDxf/Entities/MLeaderContext.cs | Collection<MLeaderNode> Leaders { get; }; MLeaderMTextContent MText { get; set; }; MLeaderBlockContent Block { get; set; }; Collection<double> ColumnHeights { get; }; Collection<double> TransformationMatrix { get; }; Vector3 Start { get; }; Vector3 End { get; }; int Index { get; set; }; Collection<MLeaderBreak> Breaks { get; }; Collection<MLeaderBreak> Breaks { get; }; Collection<MLeaderLine> Lines { get; }; Collection<Vector3> Vertices { get; }; Collection<MLeaderLineBreaks> Breaks { get; } |
| netDxf/Entities/MLeaderLine.Fields.cs | int Index { get; set; }; int Color { get; set; }; int? StoredColor { get; set; } |
| netDxf/Entities/MLeaderMTextContent.Fields.cs | string Text { get; set; }; Vector3 Normal { get; set; }; TextStyle Style { get; set; }; Vector3 Position { get; set; }; Vector3 Direction { get; set; }; double Rotation { get; set; }; double Width { get; set; }; double DefinedHeight { get; set; }; double LineSpacingFactor { get; set; }; short LineSpacingStyle { get; set; }; int Color { get; set; }; short Attachment { get; set; }; short FlowDirection { get; set; }; int BackgroundColor { get; set; }; double BackgroundScale { get; set; }; int BackgroundTransparency { get; set; }; bool UseWindowBackgroundColor { get; set; }; bool HasBackgroundFill { get; set; }; short ColumnType { get; set; }; bool AutoHeight { get; set; }; double ColumnWidth { get; set; }; double ColumnGutter { get; set; }; bool ColumnFlowReversed { get; set; }; bool UseWordBreak { get; set; } |
| netDxf/Entities/MLeaderNode.Fields.cs | bool HasLastLeaderPoint { get; set; }; bool HasDoglegVector { get; set; }; Vector3 LastLeaderPoint { get; set; }; Vector3 DoglegVector { get; set; }; int Index { get; set; }; double DoglegLength { get; set; }; short? AttachmentDirection { get; set; } |
| netDxf/Entities/MLeaderProperties.Fields.cs | DxfMLeaderStyle Style { get; set; }; int PropertyOverrideFlags { get; set; }; short LeaderType { get; set; }; int LeaderLineColor { get; set; }; Linetype LeaderLinetype { get; set; }; short LeaderLineweight { get; set; }; bool HasLanding { get; set; }; bool HasDogleg { get; set; }; double DoglegLength { get; set; }; BlockRecord ArrowHead { get; set; }; double ArrowHeadSize { get; set; }; short ContentType { get; set; }; TextStyle TextStyle { get; set; }; short TextLeftAttachment { get; set; }; int TextRightAttachment { get; set; }; short TextAngleType { get; set; }; short TextAlignmentType { get; set; }; int TextColor { get; set; }; bool HasTextFrame { get; set; }; BlockRecord Block { get; set; }; int BlockColor { get; set; }; Vector3 BlockScale { get; set; }; double BlockRotation { get; set; }; short BlockConnectionType { get; set; }; bool IsAnnotative { get; set; }; bool IsTextDirectionNegative { get; set; }; short TextEditorAlignment { get; set; }; short TextAttachmentPoint { get; set; }; double Scale { get; set; }; short? TextAttachmentDirection { get; set; }; short? TextBottomAttachment { get; set; }; short? TextTopAttachment { get; set; }; bool? LeaderExtendToText { get; set; } |
| netDxf/Entities/MLeaderStyleProperties.Fields.cs | short ContentType { get; set; }; short DrawMLeaderOrder { get; set; }; short DrawLeaderOrder { get; set; }; int MaximumLeaderPoints { get; set; }; double FirstSegmentAngle { get; set; }; double SecondSegmentAngle { get; set; }; short LeaderType { get; set; }; int LeaderLineColor { get; set; }; Linetype LeaderLinetype { get; set; }; int LeaderLineweight { get; set; }; bool HasLanding { get; set; }; double LandingGap { get; set; }; bool HasDogleg { get; set; }; double DoglegLength { get; set; }; string Description { get; set; }; BlockRecord ArrowHead { get; set; }; double ArrowHeadSize { get; set; }; string DefaultText { get; set; }; TextStyle TextStyle { get; set; }; short TextLeftAttachment { get; set; }; short TextAngleType { get; set; }; short TextAlignmentType { get; set; }; short TextRightAttachment { get; set; }; int TextColor { get; set; }; double TextHeight { get; set; }; bool HasTextFrame { get; set; }; bool TextAlignAlwaysLeft { get; set; }; double AlignSpace { get; set; }; BlockRecord Block { get; set; }; int BlockColor { get; set; }; double BlockScaleX { get; set; }; double BlockScaleY { get; set; }; double BlockScaleZ { get; set; }; bool? HasBlockScaling { get; set; }; double BlockRotation { get; set; }; bool HasBlockRotation { get; set; }; short BlockConnectionType { get; set; }; double Scale { get; set; }; bool OverwritePropertyValue { get; set; }; bool IsAnnotative { get; set; }; double BreakGap { get; set; }; short TextAttachmentDirection { get; set; }; short TextBottomAttachment { get; set; }; short TextTopAttachment { get; set; } |
| netDxf/Entities/MLine.cs | List<MLineVertex> Vertexes { get; }; double Elevation { get; set; }; double Scale { get; set; }; bool IsClosed { get; set; }; bool NoStartCaps { get; set; }; bool NoEndCaps { get; set; }; MLineJustification Justification { get; set; }; MLineStyle Style { get; set; } |
| netDxf/Entities/MLineVertex.cs | Vector2 Position { get; set; }; Vector2 Direction { get; }; Vector2 Miter { get; }; List<double>[] Distances { get; } |
| netDxf/Entities/MText.cs | bool DefaultMirrText { get; set; }; double Rotation { get; set; }; double Height { get; set; }; double LineSpacingFactor { get; set; }; MTextLineSpacingStyle LineSpacingStyle { get; set; }; MTextBackgroundFill BackgroundFill { get; set; }; MTextDrawingDirection DrawingDirection { get; set; }; double RectangleWidth { get; set; }; MTextAttachmentPoint AttachmentPoint { get; set; }; TextStyle Style { get; set; }; Vector3 Position { get; set; }; string Value { get; set; } |
| netDxf/Entities/MTextBackgroundFill.cs | MTextBackgroundFillFlags Flags { get; set; }; double? ScaleFactor { get; set; }; short? ColorIndex { get; set; }; int? TrueColor { get; set; }; string ColorName { get; set; }; int? Transparency { get; set; } |
| netDxf/Entities/MTextColumns.cs | MTextColumnType Type { get; set; }; MTextColumnStorage Storage { get; set; }; int Count { get; set; }; bool AutoHeight { get; set; }; bool FlowReversed { get; set; }; double Width { get; set; }; double Gutter { get; set; }; double DefinedHeight { get; set; }; double TotalWidth { get; }; double TotalHeight { get; set; }; double? StoredTotalWidth { get; set; }; Vector3? EmbeddedTextDirection { get; set; }; Vector3? EmbeddedInsertionPoint { get; set; }; double? EmbeddedReferenceWidth { get; set; }; IList<double> Heights { get; }; IList<MText> LinkedColumns { get; }; MTextColumns Columns { get; set; }; double? DefinedHeight { get; set; } |
| netDxf/Entities/MTextFormattingOptions.cs | bool Bold { get; set; }; bool Italic { get; set; }; bool Overline { get; set; }; bool Underline { get; set; }; bool StrikeThrough { get; set; }; bool Superscript { get; set; }; bool Subscript { get; set; }; double SuperSubScriptHeightFactor { get; set; }; AciColor Color { get; set; }; string FontName { get; set; }; double HeightFactor { get; set; }; double ObliqueAngle { get; set; }; double CharacterSpaceFactor { get; set; }; double WidthFactor { get; set; } |
| netDxf/Entities/MTextParagraphOptions.cs | double HeightFactor { get; set; }; MTextParagraphAlignment Alignment { get; set; }; MTextParagraphVerticalAlignment VerticalAlignment { get; set; }; double SpacingBefore { get; set; }; double SpacingAfter { get; set; }; double FirstLineIndent { get; set; }; double LeftIndent { get; set; }; double RightIndent { get; set; }; double LineSpacingFactor { get; set; }; MTextLineSpacingStyle LineSpacingStyle { get; set; } |
| netDxf/Entities/Mesh.cs | List<Vector3> Vertexes { get; }; List<int[]> Faces { get; }; List<MeshEdge> Edges { get; }; bool BlendCrease { get; set; }; byte SubdivisionLevel { get; set; } |
| netDxf/Entities/MeshEdge.cs | int StartVertexIndex { get; set; }; int EndVertexIndex { get; set; }; double Crease { get; set; } |
| netDxf/Entities/MultiLeader.cs | MLeaderProperties Properties { get; }; MLeaderContext Context { get; }; short? StoredVersion { get; set; }; short Version { get; }; Collection<MLeaderArrowHead> ArrowHeads { get; }; Collection<MLeaderBlockAttribute> BlockAttributes { get; } |
| netDxf/Entities/Ole2Frame.cs | Ole2FrameMetadataFields MetadataFields { get; }; Vector3 UpperLeftCorner { get; }; Vector3 LowerRightCorner { get; }; string Description { get; }; short OleVersion { get; }; OleObjectType ObjectType { get; }; short TileMode { get; }; int BinaryDataLength { get; } |
| netDxf/Entities/OleFrame.cs | short OleVersion { get; }; bool HasOleVersion { get; }; int BinaryDataLength { get; } |
| netDxf/Entities/OrdinateDimension.cs | Vector2 Origin { get; set; }; Vector2 FeaturePoint { get; set; }; Vector2 LeaderEndPoint { get; set; }; double Rotation { get; set; }; OrdinateDimensionAxis Axis { get; set; }; double Measurement { get; } |
| netDxf/Entities/Point.cs | Vector3 Position { get; set; }; double Thickness { get; set; }; double Rotation { get; set; } |
| netDxf/Entities/PolyfaceMesh.StoredRecords.cs | IReadOnlyList<PolyfaceMeshRecord> VertexRecords { get; }; IReadOnlyList<PolyfaceMeshRecord> FaceRecords { get; }; IReadOnlyList<PolyfaceMeshRecord> RecordSequence { get; }; PolyfaceMeshRecord EndSequenceRecord { get; set; }; short? DeclaredVertexCount { get; set; }; short? DeclaredFaceCount { get; set; } |
| netDxf/Entities/PolyfaceMesh.cs | Vector3[] Vertexes { get; }; IReadOnlyList<PolyfaceMeshFace> Faces { get; } |
| netDxf/Entities/PolyfaceMeshFace.cs | short[] VertexIndexes { get; }; AciColor Color { get; set; }; Layer Layer { get; set; } |
| netDxf/Entities/PolyfaceMeshRecord.cs | bool IsFaceRecord { get; set; }; PolyfaceMeshFace Face { get; }; DxfVersion SourceVersion { get; set; }; Layer Layer { get; }; Linetype Linetype { get; }; bool IsSequenceEnd { get; }; bool UsesBlockRecordOwner { get; set; }; DxfObject StoredOwner { get; } |
| netDxf/Entities/PolygonMesh.StoredRecords.cs | IReadOnlyList<PolygonMeshRecord> VertexRecords { get; }; PolygonMeshRecord EndSequenceRecord { get; } |
| netDxf/Entities/PolygonMesh.cs | Vector3[] Vertexes { get; }; short U { get; }; short V { get; }; short DensityU { get; set; }; short DensityV { get; set; }; bool IsClosedInU { get; set; }; bool IsClosedInV { get; set; }; PolylineSmoothType SmoothType { get; set; }; short DefaultSurfU { get; set; }; short DefaultSurfV { get; set; } |
| netDxf/Entities/PolygonMeshRecord.cs | DxfVersion SourceVersion { get; set; }; Layer Layer { get; }; Linetype Linetype { get; }; bool IsSequenceEnd { get; }; bool UsesBlockRecordOwner { get; set; }; DxfObject StoredOwner { get; } |
| netDxf/Entities/Polyline.cs | string SubclassMarker { get; set; }; Layer Layer { get; set; }; double Thickness { get; set; }; double Elevation { get; set; }; Vector3 Normal { get; set; }; AciColor Color { get; set; }; EndSequence EndSequence { get; set; }; List<Vertex> Vertexes { get; set; }; PolylineTypeFlags Flags { get; set; }; PolylineSmoothType SmoothType { get; set; }; short M { get; set; }; short N { get; set; }; short DensityM { get; set; }; short DensityN { get; set; } |
| netDxf/Entities/Polyline2D.Fidelity.cs | double? ConstantWidth { get; set; } |
| netDxf/Entities/Polyline2D.StoredRecords.cs | IReadOnlyList<Polyline2DRecord> VertexRecords { get; }; Polyline2DRecord EndSequenceRecord { get; set; }; double? LegacyDefaultStartWidth { get; set; }; double? LegacyDefaultEndWidth { get; set; } |
| netDxf/Entities/Polyline2D.cs | short DefaultSplineSegs { get; set; }; List<Polyline2DVertex> Vertexes { get; }; bool IsClosed { get; set; }; double Thickness { get; set; }; double Elevation { get; set; }; bool LinetypeGeneration { get; set; }; PolylineSmoothType SmoothType { get; set; } |
| netDxf/Entities/Polyline2DRecord.cs | Polyline2DVertex Vertex { get; }; DxfVersion SourceVersion { get; set; }; Layer Layer { get; }; Linetype Linetype { get; }; bool IsSequenceEnd { get; }; bool UsesBlockRecordOwner { get; set; }; DxfObject StoredOwner { get; } |
| netDxf/Entities/Polyline2DVertex.cs | Vector2 Position { get; set; }; double StartWidth { get; set; }; double EndWidth { get; set; }; double? StartWidthOverride { get; set; }; double? EndWidthOverride { get; set; }; int? VertexIdentifier { get; set; }; double Bulge { get; set; } |
| netDxf/Entities/Polyline3D.StoredRecords.cs | IReadOnlyList<Polyline3DRecord> VertexRecords { get; }; Polyline3DRecord EndSequenceRecord { get; } |
| netDxf/Entities/Polyline3D.cs | short DefaultSplineSegs { get; set; }; List<Vector3> Vertexes { get; }; bool IsClosed { get; set; }; bool LinetypeGeneration { get; set; }; PolylineSmoothType SmoothType { get; set; } |
| netDxf/Entities/Polyline3DRecord.cs | DxfVersion SourceVersion { get; set; }; Layer Layer { get; }; Linetype Linetype { get; }; bool IsSequenceEnd { get; }; bool IsRemoved { get; set; }; bool UsesBlockRecordOwner { get; set; }; DxfObject StoredOwner { get; } |
| netDxf/Entities/RadialDimension.cs | Vector2 CenterPoint { get; set; }; Vector2 ReferencePoint { get; set; }; double Measurement { get; } |
| netDxf/Entities/Ray.cs | Vector3 Origin { get; set; }; Vector3 Direction { get; set; } |
| netDxf/Entities/Section.cs | bool IsErased { get; set; }; int State { get; set; }; int Flags { get; set; }; string Name { get; set; }; Vector3 VerticalDirection { get; set; }; double TopHeight { get; set; }; double BottomHeight { get; set; }; short IndicatorTransparency { get; set; }; short? StoredIndicatorColor { get; set; }; short? StoredNativeIndicatorColor { get; set; }; string IndicatorColorName { get; set; }; Collection<Vector3> Vertices { get; }; Collection<Vector3> BackLineVertices { get; }; DxfDatabaseObject GeometrySettings { get; set; }; bool HasStoredGeometrySettings { get; } |
| netDxf/Entities/Shape.cs | string Name { get; set; }; ShapeStyle Style { get; set; }; Vector3 Position { get; set; }; double Size { get; set; }; double Rotation { get; set; }; double ObliqueAngle { get; set; }; double WidthFactor { get; set; }; double Thickness { get; set; } |
| netDxf/Entities/Solid.cs | Vector2 FirstVertex { get; set; }; Vector2 SecondVertex { get; set; }; Vector2 ThirdVertex { get; set; }; Vector2 FourthVertex { get; set; }; double Elevation { get; set; }; double Thickness { get; set; } |
| netDxf/Entities/Solid3D.cs | string HistoryHandle { get; set; } |
| netDxf/Entities/Spline.cs | IReadOnlyList<Vector3> FitPoints { get; }; Vector3? StartTangent { get; set; }; Vector3? EndTangent { get; set; }; SplineKnotParameterization KnotParameterization { get; set; }; SplineCreationMethod CreationMethod { get; }; double KnotTolerance { get; set; }; double CtrlPointTolerance { get; set; }; double FitTolerance { get; set; }; short Degree { get; }; bool IsClosed { get; }; bool IsClosedPeriodic { get; set; }; Vector3[] ControlPoints { get; }; double[] Weights { get; }; double[] Knots { get; } |
| netDxf/Entities/StoredTable.Backing.cs | DxfDatabaseObject BackingContent { get; set; }; DxfStoredTableContent StoredBackingContent { get; }; bool? BackingLiteralValuesAgree { get; } |
| netDxf/Entities/StoredTable.cs | DxfVersion SourceVersion { get; }; IReadOnlyList<DxfTag> Payload { get; }; Vector3 Position { get; }; StoredTableGrid Grid { get; }; IReadOnlyList<DxfObject> References { get; }; Vector3 Normal { get; set; } |
| netDxf/Entities/StoredTableGrid.cs | int RowCount { get; }; int ColumnCount { get; }; IReadOnlyList<double> RowHeights { get; }; IReadOnlyList<double> ColumnWidths { get; }; IReadOnlyList<StoredTableCell> Cells { get; }; short StoredType { get; }; bool HasFieldReference { get; }; int? ValueType { get; }; int? StoredFlags { get; }; bool HasLiteralValue { get; }; object LiteralValue { get; }; IReadOnlyList<DxfTag> Tags { get; } |
| netDxf/Entities/Text.cs | bool DefaultMirrText { get; set; }; Vector3 Position { get; set; }; double Rotation { get; set; }; double Height { get; set; }; double Width { get; set; }; double WidthFactor { get; set; }; double ObliqueAngle { get; set; }; TextAlignment Alignment { get; set; }; TextStyle Style { get; set; }; string Value { get; set; }; bool IsBackward { get; set; }; bool IsUpsideDown { get; set; } |
| netDxf/Entities/Tolerance.cs | ToleranceEntry Entry1 { get; set; }; ToleranceEntry Entry2 { get; set; }; double TextHeight { get; set; }; string ProjectedToleranceZoneValue { get; set; }; bool ShowProjectedToleranceZoneSymbol { get; set; }; string DatumIdentifier { get; set; }; DimensionStyle Style { get; set; }; Vector3 Position { get; set; }; double Rotation { get; set; } |
| netDxf/Entities/ToleranceEntry.cs | ToleranceGeometricSymbol GeometricSymbol { get; set; }; ToleranceValue Tolerance1 { get; set; }; ToleranceValue Tolerance2 { get; set; }; DatumReferenceValue Datum1 { get; set; }; DatumReferenceValue Datum2 { get; set; }; DatumReferenceValue Datum3 { get; set; } |
| netDxf/Entities/ToleranceValue.cs | bool ShowDiameterSymbol { get; set; }; string Value { get; set; }; ToleranceMaterialCondition MaterialCondition { get; set; } |
| netDxf/Entities/Trace.cs | Vector2 FirstVertex { get; set; }; Vector2 SecondVertex { get; set; }; Vector2 ThirdVertex { get; set; }; Vector2 FourthVertex { get; set; }; double Elevation { get; set; }; double Thickness { get; set; } |
| netDxf/Entities/Underlay.cs | UnderlayDefinition Definition { get; set; }; Vector3 Position { get; set; }; Vector2 Scale { get; set; }; double Rotation { get; set; }; short Contrast { get; set; }; short Fade { get; set; }; UnderlayDisplayFlags DisplayOptions { get; set; }; ClippingBoundary ClippingBoundary { get; set; } |
| netDxf/Entities/Vertex.cs | Vector3 Position { get; set; }; short[] VertexIndexes { get; set; }; double StartWidth { get; set; }; double EndWidth { get; set; }; double Bulge { get; set; }; VertexTypeFlags Flags { get; set; }; AciColor Color { get; set; }; Layer Layer { get; set; }; Linetype Linetype { get; set; }; string SubclassMarker { get; set; } |
| netDxf/Entities/Viewport.cs | Vector3 Center { get; set; }; double Width { get; set; }; double Height { get; set; }; short Stacking { get; set; }; Vector2 ViewCenter { get; set; }; Vector2 SnapBase { get; set; }; Vector2 SnapSpacing { get; set; }; Vector2 GridSpacing { get; set; }; Vector3 ViewDirection { get; set; }; Vector3 ViewTarget { get; set; }; double LensLength { get; set; }; double FrontClipPlane { get; set; }; double BackClipPlane { get; set; }; double ViewHeight { get; set; }; double SnapAngle { get; set; }; double TwistAngle { get; set; }; short CircleZoomPercent { get; set; }; ObservableCollection<Layer> FrozenLayers { get; }; ViewportStatusFlags Status { get; set; }; Vector3 UcsOrigin { get; set; }; Vector3 UcsXAxis { get; set; }; Vector3 UcsYAxis { get; set; }; double Elevation { get; set; }; EntityObject ClippingBoundary { get; set; } |
| netDxf/Entities/Wipeout.cs | ClippingBoundary ClippingBoundary { get; set; }; double Elevation { get; set; } |
| netDxf/Entities/XLine.cs | Vector3 Origin { get; set; }; Vector3 Direction { get; set; } |

## Public properties: Objects

Declared properties only; inherited properties, methods and wire semantics are not inferred.

| Source | Public properties |
|---|---|
| netDxf/Objects/DictionaryObject.cs | Dictionary<string, string> Entries { get; }; bool IsHardOwner { get; set; }; DictionaryCloningFlags Cloning { get; set; } |
| netDxf/Objects/DxfDataTable.cs | DxfDataCellType Type { get; }; string Name { get; }; IReadOnlyList<object> Values { get; }; short StoredVersion { get; }; string Name { get; set; }; int RowCount { get; set; }; IReadOnlyList<DxfDataColumn> Columns { get; } |
| netDxf/Objects/DxfDatabaseObject.cs | DxfObjectDatabase Database { get; set; }; bool IsErased { get; set; }; string Name { get; }; DxfObject Target { get; }; bool IsHardOwner { get; }; IReadOnlyList<DxfDictionaryEntry> Entries { get; }; int Count { get; }; bool IsHardOwner { get; set; }; DictionaryCloningFlags Cloning { get; set; }; DxfObject Default { get; set; }; Collection<DxfTag> Data { get; }; DictionaryCloningFlags Cloning { get; set; }; short Schema { get; set; }; string Value { get; set; } |
| netDxf/Objects/DxfDeclaredOwnership.cs | bool IsSchemaManaged { get; } |
| netDxf/Objects/DxfGeoData.cs | Vector2 Source { get; }; Vector2 Target { get; }; int First { get; }; int Second { get; }; int Third { get; }; int Version { get; }; BlockRecord HostBlock { get; }; DxfGeoCoordinateType CoordinateType { get; set; }; Vector3 DesignPoint { get; set; }; Vector3 ReferencePoint { get; set; }; Vector3 UpDirection { get; set; }; Vector2 NorthDirection { get; set; }; double HorizontalUnitScale { get; set; }; double VerticalUnitScale { get; set; }; DrawingUnits HorizontalUnits { get; set; }; DrawingUnits VerticalUnits { get; set; }; DxfGeoScaleEstimation ScaleEstimation { get; set; }; double UserScaleFactor { get; set; }; bool SeaLevelCorrection { get; set; }; double SeaLevelElevation { get; set; }; double CoordinateProjectionRadius { get; set; }; string CoordinateSystemDefinition { get; set; }; string GeoRssTag { get; set; }; string ObservationFrom { get; set; }; string ObservationTo { get; set; }; string ObservationCoverage { get; set; }; Collection<DxfGeoMeshPoint> MeshPoints { get; }; Collection<DxfGeoMeshFace> MeshFaces { get; } |
| netDxf/Objects/DxfIdBuffer.cs | Collection<DxfObject> References { get; } |
| netDxf/Objects/DxfLayerFilter.cs | Collection<string> LayerNames { get; } |
| netDxf/Objects/DxfLayerIndex.cs | string LayerName { get; }; DxfIdBuffer Buffer { get; }; int Count { get; }; double Timestamp { get; set; }; IReadOnlyList<DxfLayerIndexEntry> Entries { get; } |
| netDxf/Objects/DxfLightList.cs | Light Light { get; }; string Name { get; }; int StoredVersion { get; set; }; Collection<DxfLightListEntry> Entries { get; } |
| netDxf/Objects/DxfMLeaderStyle.cs | MLeaderStyleProperties Properties { get; }; short? StoredEnvelopeValue { get; set; } |
| netDxf/Objects/DxfObjectDatabase.cs | DxfDocument Document { get; }; DxfDictionary Root { get; set; }; IReadOnlyList<DxfDatabaseObject> Items { get; } |
| netDxf/Objects/DxfOpaqueObject.cs | IReadOnlyList<DxfTag> Tags { get; } |
| netDxf/Objects/DxfOutputSettings.cs | PlotSettings Settings { get; }; bool DisplayFrame { get; set; } |
| netDxf/Objects/DxfSectionSettings.cs | int SectionType { get; set; }; int GeometryValue { get; set; }; int Flags { get; set; }; short ColorCode { get; set; }; short ColorIndex { get; set; }; string LayerName { get; set; }; string LinetypeName { get; set; }; double LinetypeScale { get; set; }; string PlotStyleName { get; set; }; short Lineweight { get; set; }; short FaceTransparency { get; set; }; short EdgeTransparency { get; set; }; short HatchPatternType { get; set; }; string HatchPatternName { get; set; }; double HatchAngle { get; set; }; double HatchScale { get; set; }; double HatchSpacing { get; set; }; int SectionType { get; }; int GenerationOptions { get; }; IReadOnlyList<DxfObject> SourceObjects { get; }; BlockRecord DestinationBlock { get; }; string DestinationFileName { get; }; IReadOnlyList<DxfSectionGeometrySettings> GeometrySettings { get; }; bool RepeatGeometryMarkers { get; }; int SectionType { get; set; }; IReadOnlyList<DxfSectionTypeSettings> TypeSettings { get; } |
| netDxf/Objects/DxfSortentsTable.cs | EntityObject Entity { get; }; string SortHandle { get; }; BlockRecord BlockRecord { get; set; }; Collection<DxfSortOrderEntry> Entries { get; } |
| netDxf/Objects/DxfSpatialFilter.cs | IReadOnlyList<Vector2> Boundary { get; }; Vector3 Normal { get; set; }; Vector3 Origin { get; set; }; bool IsClippingEnabled { get; set; }; double? FrontClippingDistance { get; set; }; double? BackClippingDistance { get; set; }; Matrix4 InverseInsertTransform { get; set; }; Matrix4 ClipBoundaryTransform { get; set; } |
| netDxf/Objects/DxfSpatialIndex.cs | double Timestamp { get; set; } |
| netDxf/Objects/DxfStoredCellStyleMap.cs | int Id { get; }; int StoredType { get; }; string Name { get; }; IReadOnlyList<DxfTag> FormatPayload { get; }; DxfVersion SourceVersion { get; }; IReadOnlyList<DxfTag> Payload { get; set; }; IReadOnlyList<DxfStoredCellStyleMapEntry> Entries { get; set; }; IReadOnlyList<DxfObject> References { get; } |
| netDxf/Objects/DxfStoredDimAssoc.cs | int PointIndex { get; }; short OsnapType { get; }; EntityObject Geometry { get; set; }; short SubentityType { get; }; int MarkerIndex { get; }; double NearParameter { get; }; Vector3 Point { get; }; DxfVersion SourceVersion { get; }; IReadOnlyList<DxfTag> Tags { get; }; Dimension Dimension { get; set; }; int AssociativityMask { get; }; bool IsTransSpace { get; }; short RotatedDimensionType { get; }; IReadOnlyList<DxfStoredDimAssocPoint> PointReferences { get; }; IReadOnlyList<DxfObject> References { get; } |
| netDxf/Objects/DxfStoredField.cs | DxfVersion SourceVersion { get; }; IReadOnlyList<DxfTag> Payload { get; }; string EvaluatorId { get; }; string FieldCode { get; }; IReadOnlyList<DxfStoredField> Children { get; }; IReadOnlyList<DxfObject> ReferencedObjects { get; }; IReadOnlyList<DxfObject> References { get; } |
| netDxf/Objects/DxfStoredSectionManager.cs | DxfVersion SourceVersion { get; }; bool RequiresFullUpdate { get; set; }; IReadOnlyList<DxfTag> Tags { get; set; }; IReadOnlyList<Section> Sections { get; } |
| netDxf/Objects/DxfStoredSunStudy.cs | DxfVersion SourceVersion { get; }; IReadOnlyList<DxfTag> Payload { get; }; int Version { get; }; string Name { get; }; string Description { get; }; short OutputType { get; }; string SheetSetName { get; }; bool UseSubset { get; }; string SheetSubsetName { get; }; bool SelectDates { get; }; int DateCount { get; }; bool SelectDateRange { get; }; int StartTime { get; }; int EndTime { get; }; int Interval { get; }; IReadOnlyList<bool> RawHourFlags { get; }; DxfObject PageSetup { get; set; }; DxfObject View { get; set; }; DxfObject VisualStyle { get; set; }; DxfObject TextStyle { get; set; }; IReadOnlyList<DxfObject> References { get; } |
| netDxf/Objects/DxfStoredTableContent.Value.cs | DxfStoredTableContentValueKind Kind { get; set; }; object Value { get; set; }; int PayloadIndex { get; set; }; IReadOnlyList<DxfTag> Tags { get; set; }; int? StoredFormatFlags { get; set; }; int? StoredUnitType { get; set; }; string FormatString { get; set; }; string FormattedText { get; set; }; DxfStoredTableContentValue Original { get; }; object Value { get; }; string FormattedText { get; } |
| netDxf/Objects/DxfStoredTableContent.cs | string Name { get; }; IReadOnlyList<DxfTag> Tags { get; }; DxfVersion SourceVersion { get; }; IReadOnlyList<DxfTag> Payload { get; set; }; IReadOnlyList<DxfStoredTableContentSubclass> Subclasses { get; set; }; string Name { get; set; }; string Description { get; set; }; IReadOnlyList<DxfStoredTableContentValue> StoredValues { get; set; }; int? ColumnCount { get; set; }; int? RowCount { get; set; }; DxfDatabaseObject TableStyle { get; set; }; IReadOnlyList<DxfObject> References { get; } |
| netDxf/Objects/DxfStoredTableGeometry.cs | Vector3 TopLeftDistance { get; }; Vector3 CenterDistance { get; }; double ContentWidth { get; }; double ContentHeight { get; }; double Width { get; }; double Height { get; }; int StoredValue95 { get; }; int GeometryDataFlags { get; }; double WidthWithGap { get; }; double HeightWithGap { get; }; DxfObject GeometryReference { get; set; }; IReadOnlyList<DxfStoredTableCellGeometry> Geometry { get; }; DxfVersion SourceVersion { get; }; IReadOnlyList<DxfTag> Payload { get; set; }; int RowCount { get; set; }; int ColumnCount { get; set; }; IReadOnlyList<DxfStoredTableGeometryCell> Cells { get; set; }; IReadOnlyList<DxfObject> References { get; } |
| netDxf/Objects/DxfSun.cs | int StoredVersion { get; }; bool Enabled { get; set; }; short ColorIndex { get; set; }; int? TrueColor { get; set; }; double Intensity { get; set; }; bool ShadowsEnabled { get; set; }; int JulianDay { get; set; }; int StoredTime { get; set; }; bool DaylightSavingTime { get; set; }; DxfSunShadowType ShadowType { get; set; }; short ShadowMapSize { get; set; }; byte ShadowSoftness { get; set; } |
| netDxf/Objects/DxfTableStyle.Projection.cs | string Description { get; set; }; short FlowDirection { get; set; }; short StoredFlags { get; set; }; double HorizontalCellMargin { get; set; }; double VerticalCellMargin { get; set; }; bool SuppressTitle { get; set; }; bool SuppressColumnHeading { get; set; }; string StoredTextStyleName { get; }; TextStyle TextStyle { get; set; }; DxfTableStyleRowValues Values { get; }; IReadOnlyList<DxfTag> Tags { get; }; DxfTableStyleRow Original { get; }; DxfTableStyleRowValues Values { get; }; double TextHeight { get; set; }; short CellAlignment { get; set; }; short StoredTextColor { get; set; }; short StoredFillColor { get; set; }; bool BackgroundColorEnabled { get; set; } |
| netDxf/Objects/DxfTableStyle.cs | DxfVersion SourceVersion { get; }; IReadOnlyList<DxfTag> Tags { get; set; }; DxfTableStyleHeader Header { get; set; }; IReadOnlyList<DxfTableStyleRow> Rows { get; set; }; IReadOnlyList<DxfObject> References { get; }; DxfDatabaseObject CellStyleMap { get; set; }; DxfStoredCellStyleMap StoredCellStyleMap { get; } |
| netDxf/Objects/DxfVbaProject.cs | int DataLength { get; }; byte[] Data { get; set; }; IReadOnlyList<byte[]> Chunks { get; } |
| netDxf/Objects/Group.cs | string Name { get; set; }; string Description { get; set; }; bool IsUnnamed { get; set; }; bool IsSelectable { get; set; }; EntityCollection Entities { get; }; Groups Owner { get; set; } |
| netDxf/Objects/GroupEntityChangeEventArgs.cs | EntityObject Item { get; } |
| netDxf/Objects/ImageDefinition.cs | string File { get; set; }; int Width { get; set; }; int Height { get; set; }; double HorizontalResolution { get; set; }; double VerticalResolution { get; set; }; ImageResolutionUnits ResolutionUnits { get; set; }; ImageDefinitions Owner { get; set; } |
| netDxf/Objects/ImageDefinitionReactor.cs | string ImageHandle { get; } |
| netDxf/Objects/LayerState.cs | string Description { get; set; }; string CurrentLayer { get; set; }; bool PaperSpace { get; set; }; ObservableDictionary<string, LayerStateProperties> Properties { get; }; LayerStateManager Owner { get; set; } |
| netDxf/Objects/LayerStateProperties.cs | string Name { get; }; LayerPropertiesFlags Flags { get; set; }; string LinetypeName { get; set; }; AciColor Color { get; set; }; Lineweight Lineweight { get; set; }; Transparency Transparency { get; set; } |
| netDxf/Objects/Layout.cs | Layout ModelSpace { get; }; short TabOrder { get; set; }; PlotSettings PlotSettings { get; set; }; Vector2 MinLimit { get; set; }; Vector2 MaxLimit { get; set; }; Vector3 MinExtents { get; set; }; Vector3 MaxExtents { get; set; }; Vector3 BasePoint { get; set; }; double Elevation { get; set; }; Vector3 UcsOrigin { get; set; }; Vector3 UcsXAxis { get; set; }; Vector3 UcsYAxis { get; set; }; bool IsPaperSpace { get; }; Viewport Viewport { get; set; }; Layouts Owner { get; set; }; Block AssociatedBlock { get; set; } |
| netDxf/Objects/MLineStyle.cs | MLineStyle Default { get; }; MLineStyleFlags Flags { get; set; }; string Description { get; set; }; AciColor FillColor { get; set; }; double StartAngle { get; set; }; double EndAngle { get; set; }; ObservableCollection<MLineStyleElement> Elements { get; }; MLineStyles Owner { get; set; } |
| netDxf/Objects/MLineStyleElement.cs | double Offset { get; set; }; AciColor Color { get; set; }; Linetype Linetype { get; set; } |
| netDxf/Objects/MLineStyleElementChangeEventArgs.cs | MLineStyleElement Item { get; } |
| netDxf/Objects/PaperMargin.cs | double Left { get; set; }; double Bottom { get; set; }; double Right { get; set; }; double Top { get; set; } |
| netDxf/Objects/PlotSettings.Fidelity.cs | short StandardScaleType { get; set; }; double? StandardScaleFactor { get; set; }; DxfObject ShadePlotObject { get; set; } |
| netDxf/Objects/PlotSettings.cs | string PageSetupName { get; set; }; string PlotterName { get; set; }; string PaperSizeName { get; set; }; string ViewName { get; set; }; string CurrentStyleSheet { get; set; }; PaperMargin PaperMargin { get; set; }; Vector2 PaperSize { get; set; }; Vector2 Origin { get; set; }; Vector2 WindowUpRight { get; set; }; Vector2 WindowBottomLeft { get; set; }; bool ScaleToFit { get; set; }; double PrintScaleNumerator { get; set; }; double PrintScaleDenominator { get; set; }; double PrintScale { get; }; PlotFlags Flags { get; set; }; PlotType PlotType { get; set; }; PlotPaperUnits PaperUnits { get; set; }; PlotRotation PaperRotation { get; set; }; ShadePlotMode ShadePlotMode { get; set; }; ShadePlotResolutionMode ShadePlotResolutionMode { get; set; }; short ShadePlotDPI { get; set; }; Vector2 PaperImageOrigin { get; set; } |
| netDxf/Objects/RasterVariables.cs | bool DisplayFrame { get; set; }; ImageDisplayQuality DisplayQuality { get; set; }; ImageUnits Units { get; set; } |
| netDxf/Objects/SunReferences.cs | netDxf.Objects.DxfDatabaseObject Sun { get; set; }; netDxf.Objects.DxfDatabaseObject Sun { get; set; }; netDxf.Objects.DxfDatabaseObject Sun { get; set; } |
| netDxf/Objects/UnderlayDefinition.cs | UnderlayType Type { get; }; string File { get; set; } |
| netDxf/Objects/UnderlayDgnDefinition.cs | string Layout { get; set; }; UnderlayDgnDefinitions Owner { get; set; } |
| netDxf/Objects/UnderlayDwfDefinition.cs | UnderlayDwfDefinitions Owner { get; set; } |
| netDxf/Objects/UnderlayPdfDefinition.cs | string Page { get; set; }; UnderlayPdfDefinitions Owner { get; set; } |
| netDxf/Objects/XRecord.cs | string Handle { get; set; }; string OwnerHandle { get; set; }; string Codename { get; }; DictionaryCloningFlags Flags { get; set; }; List<XRecordEntry> Entries { get; } |
| netDxf/Objects/XRecordEntry.cs | int Code { get; }; object Value { get; } |

## Public properties: Tables

Declared properties only; inherited properties, methods and wire semantics are not inferred.

| Source | Public properties |
|---|---|
| netDxf/Tables/ApplicationRegistry.cs | ApplicationRegistry Default { get; }; ApplicationRegistries Owner { get; set; } |
| netDxf/Tables/DimensionStyle.StoredSettings.cs | double TickSize { get; set; }; double TextVerticalPosition { get; set; }; bool UserPositionedText { get; set; } |
| netDxf/Tables/DimensionStyle.cs | DimensionStyle Default { get; }; DimensionStyle Iso25 { get; }; AciColor DimLineColor { get; set; }; Linetype DimLineLinetype { get; set; }; Lineweight DimLineLineweight { get; set; }; bool DimLine1Off { get; set; }; bool DimLine2Off { get; set; }; double DimLineExtend { get; set; }; double DimBaselineSpacing { get; set; }; AciColor ExtLineColor { get; set; }; Linetype ExtLine1Linetype { get; set; }; Linetype ExtLine2Linetype { get; set; }; Lineweight ExtLineLineweight { get; set; }; bool ExtLine1Off { get; set; }; bool ExtLine2Off { get; set; }; double ExtLineOffset { get; set; }; double ExtLineExtend { get; set; }; bool ExtLineFixed { get; set; }; double ExtLineFixedLength { get; set; }; Block DimArrow1 { get; set; }; Block DimArrow2 { get; set; }; Block LeaderArrow { get; set; }; double ArrowSize { get; set; }; double CenterMarkSize { get; set; }; TextStyle TextStyle { get; set; }; AciColor TextColor { get; set; }; AciColor TextFillColor { get; set; }; double TextHeight { get; set; }; DimensionStyleTextHorizontalPlacement TextHorizontalPlacement { get; set; }; DimensionStyleTextVerticalPlacement TextVerticalPlacement { get; set; }; double TextOffset { get; set; }; bool TextInsideAlign { get; set; }; bool TextOutsideAlign { get; set; }; DimensionStyleTextDirection TextDirection { get; set; }; double TextFractionHeightScale { get; set; }; bool FitDimLineForce { get; set; }; bool FitDimLineInside { get; set; }; double DimScaleOverall { get; set; }; DimensionStyleFitOptions FitOptions { get; set; }; bool FitTextInside { get; set; }; DimensionStyleFitTextMove FitTextMove { get; set; }; short AngularPrecision { get; set; }; short LengthPrecision { get; set; }; string DimPrefix { get; set; }; string DimSuffix { get; set; }; char DecimalSeparator { get; set; }; double DimScaleLinear { get; set; }; LinearUnitType DimLengthUnits { get; set; }; AngleUnitType DimAngularUnits { get; set; }; FractionFormatType FractionType { get; set; }; bool SuppressLinearLeadingZeros { get; set; }; bool SuppressLinearTrailingZeros { get; set; }; bool SuppressZeroFeet { get; set; }; bool SuppressZeroInches { get; set; }; bool SuppressAngularLeadingZeros { get; set; }; bool SuppressAngularTrailingZeros { get; set; }; double DimRoundoff { get; set; }; DimensionStyleAlternateUnits AlternateUnits { get; set; }; DimensionStyleTolerances Tolerances { get; set; }; DimensionStyles Owner { get; set; } |
| netDxf/Tables/DimensionStyleAlternateUnits.cs | bool Enabled { get; set; }; short LengthPrecision { get; set; }; string Prefix { get; set; }; string Suffix { get; set; }; double Multiplier { get; set; }; LinearUnitType LengthUnits { get; set; }; bool StackUnits { get; set; }; bool SuppressLinearLeadingZeros { get; set; }; bool SuppressLinearTrailingZeros { get; set; }; bool SuppressZeroFeet { get; set; }; bool SuppressZeroInches { get; set; }; double Roundoff { get; set; } |
| netDxf/Tables/DimensionStyleOverride.cs | DimensionStyleOverrideType Type { get; }; object Value { get; } |
| netDxf/Tables/DimensionStyleOverrideChangeEventArgs.cs | DimensionStyleOverride Item { get; } |
| netDxf/Tables/DimensionStyleTolerances.cs | DimensionStyleTolerancesDisplayMethod DisplayMethod { get; set; }; double UpperLimit { get; set; }; double LowerLimit { get; set; }; DimensionStyleTolerancesVerticalPlacement VerticalPlacement { get; set; }; short Precision { get; set; }; bool SuppressLinearLeadingZeros { get; set; }; bool SuppressLinearTrailingZeros { get; set; }; bool SuppressZeroFeet { get; set; }; bool SuppressZeroInches { get; set; }; short AlternatePrecision { get; set; }; bool AlternateSuppressLinearLeadingZeros { get; set; }; bool AlternateSuppressLinearTrailingZeros { get; set; }; bool AlternateSuppressZeroFeet { get; set; }; bool AlternateSuppressZeroInches { get; set; } |
| netDxf/Tables/Layer.cs | Layer Default { get; }; string Description { get; set; }; Linetype Linetype { get; set; }; AciColor Color { get; set; }; bool IsVisible { get; set; }; bool IsFrozen { get; set; }; bool IsLocked { get; set; }; bool Plot { get; set; }; Lineweight Lineweight { get; set; }; Transparency Transparency { get; set; }; Layers Owner { get; set; } |
| netDxf/Tables/Linetype.cs | Linetype ByLayer { get; }; Linetype ByBlock { get; }; Linetype Continuous { get; }; Linetype Center { get; }; Linetype DashDot { get; }; Linetype Dashed { get; }; Linetype Dot { get; }; bool IsByLayer { get; }; bool IsByBlock { get; }; string Description { get; set; }; ObservableCollection<LinetypeSegment> Segments { get; }; Linetypes Owner { get; set; } |
| netDxf/Tables/LinetypeSegment.cs | LinetypeSegmentType Type { get; }; double Length { get; set; } |
| netDxf/Tables/LinetypeSegmentChangeEventArgs.cs | LinetypeSegment Item { get; } |
| netDxf/Tables/LinetypeShapeSegment.cs | string Name { get; set; }; ShapeStyle Style { get; set; }; Vector2 Offset { get; set; }; LinetypeSegmentRotationType RotationType { get; set; }; double Rotation { get; set; }; double Scale { get; set; } |
| netDxf/Tables/LinetypeTextSegment.cs | string Text { get; set; }; TextStyle Style { get; set; }; Vector2 Offset { get; set; }; LinetypeSegmentRotationType RotationType { get; set; }; double Rotation { get; set; }; double Scale { get; set; } |
| netDxf/Tables/ShapeStyle.Fidelity.cs | TextStyleFlags Flags { get; set; }; short TextGenerationFlags { get; set; }; double? LastHeight { get; set; } |
| netDxf/Tables/ShapeStyle.cs | string File { get; set; }; double Size { get; }; double WidthFactor { get; }; double ObliqueAngle { get; }; ShapeStyles Owner { get; set; } |
| netDxf/Tables/TableObject.cs | string Name { get; set; }; bool IsReserved { get; set; }; char[] InvalidCharacters { get; } |
| netDxf/Tables/TableObjectChangedEventArgs.cs | T OldValue { get; }; T NewValue { get; set; } |
| netDxf/Tables/TextStyle.Fidelity.cs | TextStyleFlags Flags { get; set; }; short TextGenerationFlags { get; set; }; double? LastHeight { get; set; }; TextStyleFontData ExtendedFontData { get; set; } |
| netDxf/Tables/TextStyle.cs | TextStyle Default { get; }; string FontFile { get; set; }; string BigFont { get; set; }; string FontFamilyName { get; set; }; FontStyle FontStyle { get; set; }; double Height { get; set; }; double WidthFactor { get; set; }; double ObliqueAngle { get; set; }; bool IsVertical { get; set; }; bool IsBackward { get; set; }; bool IsUpsideDown { get; set; }; TextStyles Owner { get; set; } |
| netDxf/Tables/TextStyleFontData.cs | string FamilyName { get; }; int Flags { get; }; FontStyle FontStyle { get; } |
| netDxf/Tables/UCS.cs | Vector3 Origin { get; set; }; double Elevation { get; set; }; IReadOnlyDictionary<UcsOrthographicType, Vector3> OrthographicOrigins { get; }; Vector3 XAxis { get; }; Vector3 YAxis { get; }; Vector3 ZAxis { get; }; UCSs Owner { get; set; } |
| netDxf/Tables/UcsOrthographicBase.cs | short OrthographicViewType { get; }; UCS BaseUcs { get; } |
| netDxf/Tables/UcsRelationships.cs | UcsFlags Flags { get; set; }; UCS NamedUcs { get; set; }; UCS BaseUcs { get; set; } |
| netDxf/Tables/VPort.cs | VPort Active { get; }; Vector2 ViewCenter { get; set; }; Vector2 SnapBasePoint { get; set; }; Vector2 SnapSpacing { get; set; }; Vector2 GridSpacing { get; set; }; Vector3 ViewDirection { get; set; }; Vector3 ViewTarget { get; set; }; double ViewHeight { get; set; }; double ViewAspectRatio { get; set; }; bool ShowGrid { get; set; }; bool SnapMode { get; set; }; Vector2 LowerLeftCorner { get; set; }; Vector2 UpperRightCorner { get; set; }; VPortFlags Flags { get; set; }; double LensLength { get; set; }; double FrontClippingPlane { get; set; }; double BackClippingPlane { get; set; }; double SnapRotation { get; set; }; double ViewTwist { get; set; }; ViewModeFlags ViewMode { get; set; }; short CircleSides { get; set; }; bool FastZoom { get; set; }; short UcsIcon { get; set; }; short SnapStyle { get; set; }; short SnapIsopair { get; set; }; ViewRenderMode RenderMode { get; set; }; bool UcsPerViewport { get; set; }; Vector3 UcsOrigin { get; set; }; Vector3 UcsXAxis { get; set; }; Vector3 UcsYAxis { get; set; }; short UcsOrthographicType { get; set; }; double UcsElevation { get; set; }; VPorts Owner { get; set; } |
| netDxf/Tables/View.LiveSection.cs | Section LiveSection { get; set; }; bool HasStoredLiveSection { get; } |
| netDxf/Tables/View.cs | Vector3 Target { get; set; }; Vector3 ViewDirection { get; set; }; Vector3 Camera { get; set; }; Vector2 ViewCenter { get; set; }; double Height { get; set; }; double Width { get; set; }; double Rotation { get; set; }; ViewModeFlags ViewMode { get; set; }; ViewModeFlags Viewmode { get; set; }; double LensLength { get; set; }; double Fov { get; set; }; double FrontClippingPlane { get; set; }; double BackClippingPlane { get; set; }; ViewFlags Flags { get; set; }; bool IsPaperSpace { get; set; }; ViewRenderMode RenderMode { get; set; }; bool IsCameraPlottable { get; set; }; Views Owner { get; set; } |
| netDxf/Tables/ViewUcs.cs | Vector3 Origin { get; set; }; Vector3 XAxis { get; set; }; Vector3 YAxis { get; set; }; short OrthographicType { get; set; }; double Elevation { get; set; }; UCS NamedUcs { get; set; }; UCS BaseUcs { get; set; }; ViewUcs Ucs { get; set; } |

## Public properties: Header

Declared properties only; inherited properties, methods and wire semantics are not inferred.

| Source | Public properties |
|---|---|
| netDxf/Header/HeaderVariable.cs | string Name { get; }; short GroupCode { get; }; object Value { get; set; } |
| netDxf/Header/HeaderVariables.cs | DxfVersion AcadVer { get; set; }; string HandleSeed { get; set; }; double Angbase { get; set; }; AngleDirection Angdir { get; set; }; AttMode AttMode { get; set; }; AngleUnitType AUnits { get; set; }; short AUprec { get; set; }; AciColor CeColor { get; set; }; double CeLtScale { get; set; }; Lineweight CeLweight { get; set; }; string CeLtype { get; set; }; string CLayer { get; set; }; MLineJustification CMLJust { get; set; }; double CMLScale { get; set; }; string CMLStyle { get; set; }; string DimStyle { get; set; }; double TextSize { get; set; }; string TextStyle { get; set; }; LinearUnitType LUnits { get; set; }; short LUprec { get; set; }; string DwgCodePage { get; set; }; bool Extnames { get; set; }; Vector3 InsBase { get; set; }; DrawingUnits InsUnits { get; set; }; string LastSavedBy { get; set; }; double LtScale { get; set; }; bool LwDisplay { get; set; }; bool MirrText { get; set; }; PointShape PdMode { get; set; }; double PdSize { get; set; }; short PLineGen { get; set; }; short PsLtScale { get; set; }; short SplineSegs { get; set; }; short SurfU { get; set; }; short SurfV { get; set; }; DateTime TdCreate { get; set; }; DateTime TduCreate { get; set; }; DateTime TdUpdate { get; set; }; DateTime TduUpdate { get; set; }; TimeSpan TdinDwg { get; set; }; UCS CurrentUCS { get; set; } |

